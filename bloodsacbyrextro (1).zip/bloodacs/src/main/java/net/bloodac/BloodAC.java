package net.bloodac;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class BloodAC extends JavaPlugin {
    // publishable key herkese acik olacak sekilde tasarlanmistir; yetkiler schema.sql'deki RLS politikalariyla sinirlidir
    private static final String PUBLIC_KEY = "sb_publishable_I2yykmzeHaRiImnW-UXn-A_Fap7WU6T";

    private final Map<UUID, PlayerData> data = new ConcurrentHashMap<>();
    private final Set<UUID> alertsOff = ConcurrentHashMap.newKeySet();
    private final ConcurrentLinkedQueue<JsonObject> sampleQueue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<JsonObject> violationQueue = new ConcurrentLinkedQueue<>();

    private Supabase db;
    private volatile Model model;
    private Dataset dataset;
    private RawDataset raw;
    private org.bukkit.configuration.file.YamlConfiguration anim;

    @Override
    public void onEnable() {
        try {
            Class.forName("net.kyori.adventure.text.Component");
            Bukkit.class.getMethod("getTPS");
        } catch (ReflectiveOperationException e) {
            getLogger().severe("BloodAC Paper (1.20.1+) gerektirir; Spigot/Bukkit desteklenmez. Eklenti kapatiliyor.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        saveDefaultConfig();
        // ilk kurulumda hazir egitim verisini yerine koy (var olan veri.dat'in uzerine yazmaz)
        if (!veri().exists()) saveResource("veri.dat", false);
        dataset = new Dataset(veri());
        raw = new RawDataset(new java.io.File(getDataFolder(), "veri3.dat"));
        try { dataset.migrate(); } catch (java.io.IOException e) { getLogger().warning("veri.dat donusturulemedi: " + e.getMessage()); }
        setup();
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        BloodCommand cmd = new BloodCommand(this);
        getCommand("bloodac").setExecutor(cmd);
        getCommand("bloodac").setTabCompleter(cmd);

        // kuyruklari 5 sn'de bir Supabase'e yaz
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, this::flush, 20L, 20L);
        // VL azalmasi
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
            double dec = getConfig().getDouble("vl.decay-per-minute", 1.0);
            for (PlayerData pd : data.values()) pd.vl.replaceAll((k, v) -> Math.max(0, v - dec));
        }, 1200L, 1200L);
    }

    @Override
    public void onDisable() {
        if (db == null) return;
        try {
            java.util.concurrent.CompletableFuture.allOf(
                    send("bloodac_violations", violationQueue), send("bloodac_samples", sampleQueue)
            ).get(3, java.util.concurrent.TimeUnit.SECONDS);
        } catch (Exception ignored) { /* kapanista beklemeyi birak */ }
    }

    public void setup() {
        reloadConfig();
        loadAnimation();
        String url = getConfig().getString("supabase.url", "");
        String key = getConfig().getString("supabase.secret-key", "");
        if (key.isBlank()) key = PUBLIC_KEY; // yalnizca RLS ile kisitli publishable key
        if (url.contains("PROJE-ID")) {
            getLogger().warning("config.yml icinde supabase.url ayarlanmamis; veritabani kapali.");
            db = null;
        } else {
            db = new Supabase(url, key);
        }
        loadModel(); // yerel model.json DB olmadan da yuklenir
    }

    private java.io.File modelFile() { return new java.io.File(getDataFolder(), "model.json"); }

    public void loadModel() {
        if (modelFile().exists()) {
            try (var r = new java.io.FileReader(modelFile(), java.nio.charset.StandardCharsets.UTF_8)) {
                Model m = Model.fromJson(com.google.gson.JsonParser.parseReader(r).getAsJsonObject());
                if (m != null) { model = m; getLogger().info("AI modeli yuklendi (model.json, " + m.n + " ozellik)."); return; }
            } catch (Exception e) { getLogger().warning("model.json okunamadi: " + e.getMessage()); }
        }
        if (db == null) return;
        db.select("bloodac_model", "select=model&id=eq.1").whenComplete((rows, err) -> {
            if (err != null) { getLogger().warning("Model yuklenemedi: " + err.getMessage()); return; }
            if (rows.size() == 0) { getLogger().info("Kayitli model yok. /bloodac egit ile egit."); return; }
            Model m = Model.fromJson(rows.get(0).getAsJsonObject().getAsJsonObject("model"));
            if (m == null) { getLogger().info("DB'deki model eski surum; /bloodac egit ile yeniden egit."); return; }
            model = m;
            getLogger().info("AI modeli yuklendi (DB).");
        });
    }

    private void loadAnimation() {
        for (String f : new String[]{"animasyon.yml", "animasyon-turuncu.yml", "animasyon-gunes.yml"}) {
            if (!new java.io.File(getDataFolder(), f).exists()) saveResource(f, false);
        }
        String name = getConfig().getString("punish.animation-file", "animasyon.yml");
        java.io.File file = new java.io.File(getDataFolder(), name);
        anim = file.exists() ? org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(file) : null;
        if (anim == null) getLogger().warning("Animasyon dosyasi bulunamadi: " + name + " (animasyonsuz atilacak)");
    }

    public org.bukkit.configuration.file.YamlConfiguration animation() { return anim; }

    /** Ceza: animasyon (varsa) + sunucudan atma. */
    public void punish(Player p) {
        PlayerData pd = data(p);
        if (pd.punishing) return;
        pd.punishing = true;
        String info = "kick";
        double vlSum = 0;
        for (double v : pd.vl.values()) vlSum += v;
        final int vlTotal = (int) Math.round(vlSum);
        JsonObject row = new JsonObject();
        row.addProperty("player_uuid", p.getUniqueId().toString());
        row.addProperty("player_name", p.getName());
        row.addProperty("check_name", "Ceza (Kick)");
        row.addProperty("vl", 0);
        row.addProperty("info", info + " vl=" + vlTotal);
        violationQueue.add(row);
        getLogger().info(p.getName() + " cezalandirildi (kick, vl=" + vlTotal + ").");

        Runnable kick = () -> {
            pd.punishing = false;
            if (!p.isOnline()) return;
            p.kick(component(getConfig().getString("punish.kick-message", "BloodAC VL {vl} Detected")
                    .replace("{vl}", String.valueOf(vlTotal)).replace("{player}", p.getName())));
            String cmd = getConfig().getString("punish.command", "").replace("{player}", p.getName());
            if (!cmd.isBlank()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        };
        if (getConfig().getBoolean("punish.animation", true) && anim != null) {
            Animation.play(this, p, anim, false, kick);
        } else {
            kick.run();
        }
    }

    public Supabase db() { return db; }
    public Model model() { return model; }
    public PlayerData data(Player p) { return data.computeIfAbsent(p.getUniqueId(), u -> new PlayerData()); }
    public void drop(UUID u) { data.remove(u); }
    public Set<UUID> alertsOff() { return alertsOff; }
    /** Kayit modunda alinan bir ornegi yerel ham veriye (veri3.dat) ve Supabase kuyruguna yazar. */
    public void recordSample(String label, int group, double[][] rows, double[] features, String player) {
        JsonObject o = new JsonObject();
        o.addProperty("player_name", player);
        o.addProperty("label", label);
        JsonArray arr = new JsonArray();
        for (double d : features) arr.add(d);
        o.add("features", arr);
        sampleQueue.add(o);
        try {
            raw.append(label.equals("cheat") ? 1 : 0, group, rows);
        } catch (java.io.IOException e) {
            getLogger().warning("veri3.dat yazilamadi: " + e.getMessage());
        }
    }

    /** /bloodac veri: yerel veri seti ozeti. */
    public List<String> datasetSummary() {
        List<String> out = new ArrayList<>();
        var legacy = dataset.readAll();
        var rr = raw.readAll();
        int[] l9 = new int[2], l21 = new int[2];
        for (var r : legacy) { int c = r.label() == 1 ? 1 : 0; if (r.x().length >= 21) l21[c]++; else l9[c]++; }
        int[] rc = new int[2];
        java.util.Set<Integer>[] sess = new java.util.Set[]{new java.util.HashSet<Integer>(), new java.util.HashSet<Integer>()};
        for (var r : rr) { int c = r.label(); rc[c]++; sess[c].add(r.group()); }
        out.add("§7Eski veri (veri.dat): §aLegit " + (l9[0] + l21[0]) + " §7| §cCheat " + (l9[1] + l21[1])
                + " §8(9 ozellik: " + l9[0] + "/" + l9[1] + ", 21 ozellik: " + l21[0] + "/" + l21[1] + ")");
        out.add("§7Ham veri (veri3.dat): §aLegit " + rc[0] + " §8(" + sess[0].size() + " oturum) §7| §cCheat " + rc[1] + " §8(" + sess[1].size() + " oturum)");
        int minV3 = getConfig().getInt("ai.min-samples-v3", 80);
        out.add("§7Zengin ozellikli (46) egitim icin sinif basina en az §f" + minV3 + " §7ham ornek ve birkac farkli oturum onerilir.");
        return out;
    }

    private java.io.File veri() { return new java.io.File(getDataFolder(), "veri.dat"); }

    private static final java.util.regex.Pattern HEX = java.util.regex.Pattern.compile("&#([A-Fa-f0-9]{6})");

    /** &#RRGGBB ve &a/&l gibi klasik kodlari §-formatina cevirir (sendMessage ve Component icin). */
    public String color(String s) {
        if (s == null) return "";
        var m = HEX.matcher(s);
        var sb = new StringBuilder();
        while (m.find()) {
            StringBuilder r = new StringBuilder("§x");
            for (char c : m.group(1).toCharArray()) r.append('§').append(c);
            m.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(r.toString()));
        }
        m.appendTail(sb);
        return ChatColor.translateAlternateColorCodes('&', sb.toString());
    }

    /** Renk kodlu yaziyi Adventure Component'e cevirir (hex dahil). */
    public net.kyori.adventure.text.Component component(String s) {
        return net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(color(s));
    }
    public String prefix() { return color(getConfig().getString("messages.prefix", "&8[&cBloodAC&8] ")); }

    /** Bir ihlal isle: VL arttir, staff'a bildir, DB'ye logla, gerekirse cezalandir. */
    public void flag(Player p, String check, double add, String info) {
        PlayerData pd = data(p);
        long nowMs = System.currentTimeMillis();
        // ayni kontrolden arka arkaya gelen flag'ler tek sayilir (VL sisirmesini onler)
        Long last = pd.lastFlagMs.get(check);
        long cd = check.startsWith("Aim") ? getConfig().getLong("ai.flag-cooldown-ms", 1000) : getConfig().getLong("vl.flag-cooldown-ms", 3000);
        if (last != null && nowMs - last < cd) return;
        pd.lastFlagMs.put(check, nowMs);
        synchronized (pd.flagLog) {
            pd.flagLog.addLast(nowMs);
            while (pd.flagLog.size() > 100) pd.flagLog.removeFirst();
            long win = getConfig().getLong("punish.window-minutes", 10) * 60_000L;
            while (win > 0 && !pd.flagLog.isEmpty() && nowMs - pd.flagLog.peekFirst() > win) pd.flagLog.removeFirst();
        }
        double vl = pd.vl.merge(check, add, Double::sum);
        String vlStr = String.format("%.1f", vl);

        String msg = prefix() + color(getConfig().getString("messages.alert", "")
                .replace("{player}", p.getName()).replace("{check}", check)
                .replace("{vl}", vlStr).replace("{info}", info));
        getLogger().info(ChatColor.stripColor(msg));
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("bloodac.alerts") && !alertsOff.contains(staff.getUniqueId())) staff.sendMessage(msg);
        }

        JsonObject row = new JsonObject();
        row.addProperty("player_uuid", p.getUniqueId().toString());
        row.addProperty("player_name", p.getName());
        row.addProperty("check_name", check);
        row.addProperty("vl", vl);
        row.addProperty("info", info);
        violationQueue.add(row);

        int need = getConfig().getInt("punish.flags-to-kick", 2);
        if (need > 0) {
            int recent;
            synchronized (pd.flagLog) { recent = pd.flagLog.size(); }
            if (recent >= need && !pd.punishing) {
                synchronized (pd.flagLog) { pd.flagLog.clear(); }
                punish(p);
            }
        }
    }

    /** Flag'ten once: kanit biriktikce yetkililere action bar ile canli uyari (VL/DB'ye yazilmaz). */
    public void warn(Player p, int pct) {
        var msg = net.kyori.adventure.text.Component.text(
                p.getName() + " - AI kaniti %" + pct, net.kyori.adventure.text.format.NamedTextColor.YELLOW);
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("bloodac.alerts") && !alertsOff.contains(staff.getUniqueId())) staff.sendActionBar(msg);
        }
    }

    private void flush() {
        if (db == null) return;
        send("bloodac_violations", violationQueue);
        send("bloodac_samples", sampleQueue);
    }

    private java.util.concurrent.CompletableFuture<Void> send(String table, ConcurrentLinkedQueue<JsonObject> q) {
        if (q.isEmpty()) return java.util.concurrent.CompletableFuture.completedFuture(null);
        JsonArray arr = new JsonArray();
        List<JsonObject> batch = new ArrayList<>();
        JsonObject o;
        while ((o = q.poll()) != null) { arr.add(o); batch.add(o); }
        return db.insert(table, arr).<Void>thenApply(r -> null).exceptionally(e -> {
            // gecici hata (ag/limit): satirlari geri koy, sonraki turda tekrar dene (kuyruk siniri 2000)
            if (q.size() < 2000) q.addAll(batch);
            getLogger().warning(table + " yazilamadi (tekrar denenecek): " + e.getMessage());
            return null;
        });
    }

    private final java.util.concurrent.atomic.AtomicBoolean training = new java.util.concurrent.atomic.AtomicBoolean();

    private record Candidate(int n, Model model, Model.Report rep) {}

    /**
     * Egitim: ham (veri3.dat) ve eski (veri.dat) verilerden 46 / 21 / 9 ozellikli adaylar egitilir; oturum bazli capraz
     * dogrulamada en yuksek AUC'u veren secilir ve yuklenir.
     */
    public void train(org.bukkit.command.CommandSender sender) {
        if (!training.compareAndSet(false, true)) { sender.sendMessage(prefix() + "§cEgitim zaten suruyor."); return; }
        sender.sendMessage(prefix() + "§7Ornekler yukleniyor...");
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> { try {
            int min = getConfig().getInt("ai.min-samples-per-class", 30);
            int minV3 = getConfig().getInt("ai.min-samples-v3", 80);
            List<Dataset.Rec> legacy = new ArrayList<>(dataset.readAll());
            List<RawDataset.Rec> rawRecs = raw.readAll();
            if (legacy.isEmpty() && rawRecs.isEmpty() && db != null) {
                try {
                    for (var e : db.select("bloodac_samples", "select=label,features&limit=20000").get()) {
                        JsonObject o = e.getAsJsonObject();
                        JsonArray f = o.getAsJsonArray("features");
                        double[] x = new double[f.size()];
                        for (int i = 0; i < x.length; i++) x[i] = f.get(i).getAsDouble();
                        legacy.add(new Dataset.Rec(o.get("label").getAsString().equals("cheat") ? 1 : 0, x));
                    }
                } catch (Exception e) { reply(sender, "§cOrnekler alinamadi: " + e.getMessage()); return; }
            }
            for (String line : datasetSummary()) reply(sender, line);

            List<Candidate> cands = new ArrayList<>();
            for (int n : new int[]{Features.V3, PlayerData.FEATURES, PlayerData.LEGACY_FEATURES}) {
                List<double[]> xs = new ArrayList<>();
                List<Integer> ys = new ArrayList<>(), gs = new ArrayList<>();
                for (var r : rawRecs) {
                    if (r.rows().length != PlayerData.WINDOW) continue;
                    xs.add(Features.compute(r.rows(), n));
                    ys.add(r.label());
                    gs.add(r.group() & 0x7fffffff);
                }
                if (n < Features.V3) {
                    for (var r : legacy) {
                        if (r.x().length < n) continue;
                        xs.add(java.util.Arrays.copyOf(r.x(), n));
                        ys.add(r.label());
                        gs.add(-1);
                    }
                }
                int[] cnt = new int[2];
                for (int y : ys) cnt[y == 1 ? 1 : 0]++;
                int need = n == Features.V3 ? minV3 : min;
                if (cnt[0] < need || cnt[1] < need) {
                    reply(sender, "§8n=" + n + " ozellik: atlandi (legit " + cnt[0] + ", cheat " + cnt[1] + "; en az " + need + "/sinif)");
                    continue;
                }
                reply(sender, "§7n=" + n + " ozellik egitiliyor (legit " + cnt[0] + ", cheat " + cnt[1] + ")...");
                double[][] X = xs.toArray(new double[0][]);
                double[] y = new double[ys.size()];
                int[] g = new int[gs.size()];
                for (int i = 0; i < y.length; i++) { y[i] = ys.get(i); g[i] = gs.get(i); }
                Model.Report rep = new Model.Report();
                Model m = Model.train(X, y, g, n, rep,
                        getConfig().getDouble("ai.max-false-flags-per-1000", 0.2), getConfig().getDouble("ai.safety-margin", 1.1),
                        getConfig().getDouble("ai.clean-window-weight", 0.4), getConfig().getDouble("ai.min-evidence", 7.0),
                        getConfig().getDouble("ai.confirm-prob", 0.8), java.util.Arrays.copyOf(Features.NAMES, Math.min(n, Features.NAMES.length)));
                cands.add(new Candidate(n, m, rep));
                reply(sender, String.format("§8  n=%d: AUC %.3f | yakalama %%%.1f | yanlis alarm %%%.1f", n, rep.auc, rep.recall * 100, rep.falsePositiveRate * 100));
            }
            if (cands.isEmpty()) {
                reply(sender, "§cYetersiz ornek (en az " + min + "/sinif). /bloodac kayit <oyuncu> <legit|cheat> ile veri topla.");
                return;
            }
            Candidate best = cands.get(0);
            for (Candidate c : cands) if (c.rep().auc > best.rep().auc + 0.002) best = c;
            Model m = best.model();
            Model.Report rep = best.rep();
            model = m;
            try (var w = new java.io.FileWriter(modelFile(), java.nio.charset.StandardCharsets.UTF_8)) {
                w.write(m.toJson().toString());
            } catch (java.io.IOException e) { reply(sender, "§eModel dosyaya yazilamadi: " + e.getMessage()); }

            reply(sender, String.format("§aSecilen: %d ozellik §8(oturum bazli capraz dogrulama)§a: AUC %.3f | dogruluk %%%.1f | hileyi yakalama %%%.1f | kesinlik %%%.1f | yanlis alarm %%%.1f",
                    best.n(), rep.auc, rep.accuracy * 100, rep.recall * 100, rep.precision * 100, rep.falsePositiveRate * 100));
            reply(sender, String.format("§7Kanit esigi: §f%.1f §8| §7simule yanlis flag: §f%.2f/1000 pencere §8| §7hileciyi ort. §f%.1f §7pencerede yakalar",
                    m.cusumH, rep.falsePer1000, rep.meanDetect));
            if (!rep.topFeatures.isEmpty()) reply(sender, "§7En etkili ozellikler: §f" + String.join(", ", rep.topFeatures));
            if (rep.groups < 6 && best.n() > PlayerData.LEGACY_FEATURES) {
                reply(sender, "§eUyari: yalnizca " + rep.groups + " oturum var; farkli oyunculardan/farkli gunlerde daha cok kayit al.");
            }
            if (db != null) {
                JsonObject row = new JsonObject();
                row.addProperty("id", 1);
                row.add("model", m.toJson());
                row.addProperty("updated_at", java.time.Instant.now().toString());
                db.upsert("bloodac_model", row).exceptionally(err -> {
                    getLogger().info("Model DB'ye yazilamadi (secret key yok): " + err.getMessage());
                    return null;
                });
            }
        } catch (Exception ex) {
            reply(sender, "§cEgitim hatasi: " + ex);
            getLogger().warning("Egitim hatasi: " + ex);
        } finally { training.set(false); } });
    }

    public String modelInfo() {
        Model m = model;
        return m == null ? "§cyok (/bloodac egit)" : "§ayuklu §7(" + m.n + " ozellik, kanit esigi " + String.format("%.1f", m.cusumH) + ")";
    }

    public void reply(org.bukkit.command.CommandSender s, String msg) {
        Bukkit.getScheduler().runTask(this, () -> s.sendMessage(prefix() + msg));
    }
}
