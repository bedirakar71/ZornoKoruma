package net.bloodac;

import java.util.ArrayDeque;
import java.util.Map;
import java.util.UUID;

public final class PlayerData {
    public static final int WINDOW = 40;
    /** Ilk 9 ozellik eski surumle ayni (geriye uyumluluk); gerisi v2. */
    public static final int FEATURES = 21;
    public static final int LEGACY_FEATURES = 9;

    private final ArrayDeque<double[]> deltas = new ArrayDeque<>(); // {dyaw, dpitch, hedefe aci hatasi (-1 = hedef yok)}
    private float lastYaw, lastPitch;
    private boolean hasLast;

    public final Map<String, Double> vl = new java.util.concurrent.ConcurrentHashMap<>();
    public final ArrayDeque<Double> probs = new ArrayDeque<>();
    public final Map<String, Double> buf = new java.util.concurrent.ConcurrentHashMap<>();
    public final Map<UUID, Long> recentTargets = new java.util.HashMap<>();
    /** Giris/isinlanma/respawn sonrasi kisa sure kontrol yapma (yanlis alarm onlemi). */
    public long ignoreUntilMs = System.currentTimeMillis() + 3000;
    public volatile boolean frozen, punishing;
    public double cusum;
    /** AI kaniti latch (kilit) baslangic zamani; 0 = kilitli degil. */
    public long latchMs;
    /** Kilidin o anki tabani (ulasilan en yuksek kanit); latchFlagged = kilit bir flag sonrasi kuruldu. */
    public double latchFloor;
    public boolean latchFlagged;
    public long cusumMs, lastMoveMs;
    public final Map<String, Long> lastFlagMs = new java.util.concurrent.ConcurrentHashMap<>();
    public final ArrayDeque<Long> flagLog = new ArrayDeque<>();
    public long lastSampleMs;
    public long lastAttackMs;
    public UUID lastTarget;
    public String recordLabel; // null = kayit yok
    public UUID recorder; // kaydi baslatan yetkili
    public int recHits, recSamples, recProgress, sessionId;
    public String recWhy;
    // AuraFix durumu
    public final ArrayDeque<Boolean> snapHits = new ArrayDeque<>();
    public long afLastEvalMs, cancelUntilMs;
    /** Esya/el degisimi (swap) ve blok kirma baslangici zamanlari. */
    public long lastSwapMs, pendingHitMs;
    /** Reach-spoof izleme: son hareket vektoru/baslangici, supheli ileri atilis ve zamani. */
    public long lastMoveVecMs, spoofMs;
    public double[] lastMoveVec = new double[3], lastMoveFrom = new double[3], spoofVec = new double[3];
    /** {zaman, paketlenmis blok konumu} */
    public final ArrayDeque<long[]> blockDmg = new ArrayDeque<>();

    /** Ihlal tamponu: kotu olay +1, temiz olay -0.5; 'need'e ulasinca true doner ve sifirlanir. */
    public boolean buffer(String key, boolean bad, double need) {
        double v = buf.merge(key, bad ? 1.0 : -0.5, Double::sum);
        if (v < 0) { buf.put(key, 0.0); return false; }
        if (bad && v >= need) { buf.put(key, 0.0); return true; }
        return false;
    }

    /** Pencerenin kopyasi: her satir {dyaw, dpitch, hedef merkezine hata, hedef gozune hata, pitch}. */
    public double[][] snapshot() {
        return deltas.toArray(new double[0][]);
    }

    public void rotate(float yaw, float pitch, double err, double errEye) {
        if (hasLast) {
            double dy = yaw - lastYaw;
            while (dy > 180) dy -= 360;
            while (dy < -180) dy += 360;
            deltas.addLast(new double[]{dy, pitch - lastPitch, err, errEye, pitch});
            if (deltas.size() > WINDOW) deltas.removeFirst();
        }
        lastYaw = yaw;
        lastPitch = pitch;
        hasLast = true;
    }

    /** Bakis penceresinin doluluk yuzdesi (0-100); 100 olunca ornek alinabilir. */
    public int windowFill() { return Math.min(100, deltas.size() * 100 / WINDOW); }

    public void resetRotation() {
        deltas.clear();
        hasLast = false;
    }

    /** Yeterli veri yoksa null. */
    public double[] features() {
        if (deltas.size() < WINDOW) return null;
        return base21(snapshot());
    }

    /** Ilk n ozellik (n <= Features.V3); n > 21 ise ham pencereden zengin ozellikler. Veri yoksa null. */
    public double[] featuresN(int n) {
        if (deltas.size() < WINDOW) return null;
        return Features.compute(snapshot(), n);
    }

    /** Ham pencere kopyasi ({dy, dp, merkez hata, goz hata, mutlak pitch}); yetersizse null. */
    public double[][] rawWindow() {
        return deltas.size() < WINDOW ? null : snapshot();
    }

    /** Ilk 21 ozellik; rows.length == WINDOW olmali. */
    public static double[] base21(double[][] rows) {
        double[] dy = new double[WINDOW], dp = new double[WINDOW], er = new double[WINDOW];
        for (int i = 0; i < WINDOW; i++) { dy[i] = rows[i][0]; dp[i] = rows[i][1]; er[i] = rows[i][2]; }

        double[] ay = abs(dy), ap = abs(dp);
        double[] accY = new double[WINDOW - 1], accP = new double[WINDOW - 1];
        double accSum = 0;
        for (int k = 1; k < WINDOW; k++) {
            accY[k - 1] = Math.abs(dy[k] - dy[k - 1]);
            accP[k - 1] = Math.abs(dp[k] - dp[k - 1]);
            accSum += accY[k - 1];
        }
        int snaps = 0, flips = 0, zy = 0, zp = 0;
        for (int k = 0; k < WINDOW - 1; k++) {
            if (ay[k] > 25 && ay[k + 1] < 1.0) snaps++;
            if (dy[k] * dy[k + 1] < 0 && ay[k] > 0.05 && ay[k + 1] > 0.05) flips++;
        }
        for (int k = 0; k < WINDOW; k++) {
            if (ay[k] < 0.01) zy++;
            if (ap[k] < 0.01) zp++;
        }
        double meanY = mean(ay);

        double[] f = new double[FEATURES];
        f[0] = meanY; f[1] = std(ay); f[2] = max(ay);
        f[3] = mean(ap); f[4] = std(ap); f[5] = max(ap);
        f[6] = std(accY);
        f[7] = snaps / (double) (WINDOW - 1);
        f[8] = (accSum / (WINDOW - 1)) / (meanY + 1e-3);
        // --- v2 ---
        f[9] = std(accP);
        f[10] = zy / (double) WINDOW;
        f[11] = zp / (double) WINDOW;
        f[12] = Math.abs(corr(dy, dp));
        f[13] = flips / (double) (WINDOW - 1);
        f[14] = entropy(ay);

        // hedefe gore ozellikler (yalnizca hedef bilinen adimlar)
        int cnt = 0;
        for (double e : er) if (e >= 0) cnt++;
        f[15] = cnt / (double) WINDOW;
        if (cnt >= 10) {
            double[] e = new double[cnt];
            int c = 0;
            for (double v : er) if (v >= 0) e[c++] = v;
            double dsum = 0, lock = 0, mn = Double.MAX_VALUE;
            for (int k = 0; k < cnt; k++) {
                mn = Math.min(mn, e[k]);
                if (e[k] < 2.0) lock++;
                if (k > 0) dsum += Math.abs(e[k] - e[k - 1]);
            }
            f[16] = mean(e);
            f[17] = std(e);
            f[18] = mn;
            f[19] = dsum / Math.max(1, cnt - 1);
            f[20] = lock / cnt;
        }
        for (int k = 0; k < f.length; k++) if (Double.isNaN(f[k]) || Double.isInfinite(f[k])) f[k] = 0;
        return f;
    }

    private static double[] abs(double[] a) {
        double[] r = new double[a.length];
        for (int i = 0; i < a.length; i++) r[i] = Math.abs(a[i]);
        return r;
    }

    private static double mean(double[] a) {
        double s = 0;
        for (double v : a) s += v;
        return s / a.length;
    }

    private static double std(double[] a) {
        double m = mean(a), s = 0;
        for (double v : a) s += (v - m) * (v - m);
        return Math.sqrt(s / a.length);
    }

    private static double max(double[] a) {
        double m = 0;
        for (double v : a) m = Math.max(m, v);
        return m;
    }

    private static double corr(double[] a, double[] b) {
        double ma = mean(a), mb = mean(b), sab = 0, sa = 0, sb = 0;
        for (int i = 0; i < a.length; i++) {
            sab += (a[i] - ma) * (b[i] - mb);
            sa += (a[i] - ma) * (a[i] - ma);
            sb += (b[i] - mb) * (b[i] - mb);
        }
        return sa < 1e-9 || sb < 1e-9 ? 0 : sab / Math.sqrt(sa * sb);
    }

    private static final double[] EDGES = {0.05, 0.1, 0.25, 0.5, 1, 2, 4, 8, 16, 32, 64};

    /** |delta| dagiliminin normalize Shannon entropisi (0-1). */
    private static double entropy(double[] a) {
        int[] bins = new int[EDGES.length + 1];
        for (double v : a) {
            int b = 0;
            while (b < EDGES.length && v >= EDGES[b]) b++;
            bins[b]++;
        }
        double h = 0;
        for (int c : bins) if (c > 0) { double p = c / (double) a.length; h -= p * Math.log(p); }
        return h / Math.log(bins.length);
    }
}
