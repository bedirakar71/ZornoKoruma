package net.bloodac;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * veri3.dat: HAM bakis pencereleri ("BAC3"). Kayit = etiket(1 bayt), oturum kimligi(int), adim sayisi(1 bayt), adim*5 float.
 * Ham veri sakli oldugu icin ozellikler sonradan yeniden hesaplanabilir; yeni ozellik icin yeniden kayit gerekmez.
 */
public final class RawDataset {
    private static final int MAGIC = 0x42414333;
    public static final int COLS = 5;

    public record Rec(int label, int group, double[][] rows) {}

    private final File file;

    public RawDataset(File file) { this.file = file; }

    public synchronized void append(int label, int group, double[][] rows) throws IOException {
        file.getParentFile().mkdirs();
        boolean fresh = !file.exists() || file.length() == 0;
        try (var out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file, true)))) {
            if (fresh) out.writeInt(MAGIC);
            out.writeByte(label);
            out.writeInt(group);
            out.writeByte(rows.length);
            for (double[] r : rows) for (int c = 0; c < COLS; c++) out.writeFloat((float) r[c]);
        }
    }

    public synchronized List<Rec> readAll() {
        List<Rec> list = new ArrayList<>();
        if (!file.exists() || file.length() < 4) return list;
        try (var in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            if (in.readInt() != MAGIC) return list;
            while (true) {
                int lab = in.read();
                if (lab < 0) break;
                int group = in.readInt();
                int n = in.readUnsignedByte();
                double[][] rows = new double[n][COLS];
                for (int i = 0; i < n; i++) for (int c = 0; c < COLS; c++) rows[i][c] = in.readFloat();
                list.add(new Rec(lab, group, rows));
            }
        } catch (IOException ignored) { /* yarim kalan son kayit atlanir */ }
        return list;
    }
}
