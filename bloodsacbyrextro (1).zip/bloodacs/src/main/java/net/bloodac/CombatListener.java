package net.bloodac;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

public final class CombatListener implements Listener {
    private final BloodAC plugin;

    private final AuraFix auraFix;

    @EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void onHeld(org.bukkit.event.player.PlayerItemHeldEvent e) { swap(e.getPlayer()); }

    @EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void onSwapHands(org.bukkit.event.player.PlayerSwapHandItemsEvent e) { swap(e.getPlayer()); }

    @EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void onInvClick(org.bukkit.event.inventory.InventoryClickEvent e) {
        var ct = e.getClick();
        if ((ct == org.bukkit.event.inventory.ClickType.SWAP_OFFHAND || ct == org.bukkit.event.inventory.ClickType.NUMBER_KEY)
                && e.getWhoClicked() instanceof Player p) swap(p);
    }

    @EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void onBlockDamage(org.bukkit.event.block.BlockDamageEvent e) {
        if (e.getPlayer().getGameMode() == org.bukkit.GameMode.SURVIVAL)
            {
            if (!e.getInstaBreak()) { // aninda kirilan yumusak bloklar (cim, mesale...) normal oyunda da hizli tiklanir
                var b = e.getBlock();
                long packed = ((long) b.getX() & 0x3FFFFFF) << 38 | ((long) b.getZ() & 0x3FFFFFF) << 12 | ((long) b.getY() & 0xFFF);
                auraFix.onBlockDamage(plugin.data(e.getPlayer()), System.currentTimeMillis(), packed);
            }
        }
    }

    private boolean p_bypass(Player p) { return p.hasPermission("bloodac.bypass"); }

    private void swap(Player p) {
        PlayerData pd = plugin.data(p);
        if (pd.recordLabel != null || pd.frozen || p.hasPermission("bloodac.bypass")) return;
        auraFix.onSwap(p, pd, System.currentTimeMillis());
    }

    public CombatListener(BloodAC plugin) { this.plugin = plugin; this.auraFix = new AuraFix(plugin); }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        if (to == null) return;
        Player pl = e.getPlayer();
        PlayerData pd = plugin.data(pl);
        if (pd.frozen) { e.setCancelled(true); return; }
        double err = -1, errEye = -1;
        if (pd.lastTarget != null && System.currentTimeMillis() - pd.lastAttackMs < 2500) {
            var t = org.bukkit.Bukkit.getEntity(pd.lastTarget);
            if (t != null && t.getWorld().equals(to.getWorld())) {
                Vector myEye = to.toVector().add(new Vector(0, pl.getEyeHeight(), 0));
                Vector v = t.getBoundingBox().getCenter().subtract(myEye);
                if (v.lengthSquared() > 0.01) err = Math.toDegrees(to.getDirection().angle(v));
                if (t instanceof LivingEntity le) {
                    Vector ve = le.getEyeLocation().toVector().subtract(myEye);
                    if (ve.lengthSquared() > 0.01) errEye = Math.toDegrees(to.getDirection().angle(ve));
                }
            }
        }
        long nowMs = System.currentTimeMillis();
        if (pd.recordLabel == null && !p_bypass(pl)) auraFix.onMove(pl, pd, e.getFrom(), to, nowMs);
        if (pd.lastMoveMs != 0 && nowMs - pd.lastMoveMs > 400) pd.resetRotation();
        pd.lastMoveMs = nowMs;
        pd.rotate(to.getYaw(), to.getPitch(), err, errEye);
    }

    /** Animasyon sirasinda elytra acma / havai fisek kullanma engellenir. */
    @EventHandler(ignoreCancelled = true)
    public void onGlide(org.bukkit.event.entity.EntityToggleGlideEvent e) {
        if (e.getEntity() instanceof Player p && plugin.data(p).frozen && e.isGliding()) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(org.bukkit.event.player.PlayerInteractEvent e) {
        if (plugin.data(e.getPlayer()).frozen) e.setCancelled(true);
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        PlayerData pd = plugin.data(e.getPlayer());
        pd.resetRotation();
        pd.probs.clear();
        pd.ignoreUntilMs = System.currentTimeMillis() + 3000;
    }

    @EventHandler
    public void onRespawn(org.bukkit.event.player.PlayerRespawnEvent e) {
        PlayerData pd = plugin.data(e.getPlayer());
        pd.resetRotation();
        pd.probs.clear();
        pd.ignoreUntilMs = System.currentTimeMillis() + 3000;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { plugin.drop(e.getPlayer().getUniqueId()); }

    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        // saldirgan: oyuncunun kendisi veya oyuncunun attigi ok/kartus
        Player p = e.getDamager() instanceof Player pl ? pl
                : (e.getDamager() instanceof org.bukkit.entity.Projectile pr && pr.getShooter() instanceof Player sp ? sp : null);
        if (p == null || !(e.getEntity() instanceof LivingEntity target)) return;
        PlayerData pd = plugin.data(p);
        if (pd.frozen) { e.setCancelled(true); return; }
        long now = System.currentTimeMillis();

        // kayit modu: her tur vurus sayilir (normal, supurme, ok, zirh askisi...)
        if (pd.recordLabel != null) {
            pd.lastAttackMs = now;
            pd.lastTarget = target.getUniqueId();
            record(p, pd, now);
            return;
        }
        if (p.hasPermission("bloodac.bypass")) return;
        // AuraFix: flag'li oyuncunun vuruslari kisa sure engellenir
        if (now < pd.cancelUntilMs && e.getDamager() == p) { e.setCancelled(true); return; }

        // tespit: yalnizca dogrudan yakin dovus (supurme/ok/dolayli hasar hile degil)
        if (e.getDamager() != p || e.getCause() != org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (target instanceof org.bukkit.entity.ArmorStand || target.isDead()) return;
        var gm = p.getGameMode();
        boolean bedrock = plugin.getConfig().getBoolean("checks.skip-bedrock", true) && p.getUniqueId().getMostSignificantBits() == 0L;
        boolean safe = !bedrock && now >= pd.ignoreUntilMs && !p.isInsideVehicle()
                && gm != org.bukkit.GameMode.CREATIVE && gm != org.bukkit.GameMode.SPECTATOR && !p.isDead()
                && org.bukkit.Bukkit.getAverageTickTime() <= plugin.getConfig().getDouble("checks.max-mspt", 55.0)
                && p.getPing() <= plugin.getConfig().getInt("checks.max-ping", 250);
        if (safe) {
            auraChecks(p, target, pd, now);
            if (p.isGliding()) elytraTarget(p, pd);
            else auraFix.onHit(p, pd, target, now);
        }
        pd.lastAttackMs = now;
        pd.lastTarget = target.getUniqueId();

        // AI penceresi: kisa aralikla (varsayilan 250 ms) degerlendirilir; kanit katkisi aralikla orantili oldugu icin
        // saniyedeki toplam kanit ayni kalir, ama ekran/flag cok daha sik guncellenir
        long interval = Math.max(100, plugin.getConfig().getLong("ai.eval-interval-ms", 250));
        if (now - pd.lastSampleMs < interval) return;
        Model m = plugin.model();
        // model hangi ozellik sayisini istiyorsa o kadar (en az 21: hedef orani f[15] icin) hesaplanir
        double[] f = pd.featuresN(m != null ? Math.max(m.n, PlayerData.FEATURES) : PlayerData.FEATURES);
        if (f == null) return;
        pd.lastSampleMs = now;

        if (!safe || m == null || !plugin.getConfig().getBoolean("ai.enabled", true)) return;
        // hedef takibi olmayan pencereleri (rastgele bakis) degerlendirme
        if (m.n > 15 && f[15] < plugin.getConfig().getDouble("ai.min-target-fraction", 0.25)) return;
        double prob = m.predict(f);
        // CUSUM: sureklilik gerektirir. Temiz pencereler kaniti sifira ceker, tek seferlik yuksek tahmin flag atmaz.
        // kanit aniden silinmez: sadece zamanla yavasca azalir (aura ac-kapa yapana karsi)
        if (pd.cusumMs != 0) {
            double mins = (now - pd.cusumMs) / 60000.0;
            pd.cusum = Math.max(0, pd.cusum - mins * plugin.getConfig().getDouble("ai.evidence-decay-per-minute", 1.0));
        }
        // kanit gercek gecen sureyle orantili birikir (vuruslar seyrekse bile 1 sn = 1 sn kanit); ust sinir 1 sn
        double dt = pd.cusumMs == 0 ? interval : Math.min(1000, now - pd.cusumMs);
        pd.cusumMs = now;
        double cfgSpeed = plugin.getConfig().getDouble("ai.evidence-speed", 1.5);
        pd.cusum = Math.max(0, pd.cusum + m.step(prob) * (dt / 1000.0) * cfgSpeed);
        // kilit: kanit %98'e (ayarlanabilir) ulasinca altina inmez, ulasilan en yuksek seviye taban olur
        var cfg = plugin.getConfig();
        double base = m.cusumH * cfg.getDouble("ai.latch-percent", 99) / 100.0;
        if (pd.latchMs != 0) {
            if (now - pd.latchMs > cfg.getDouble("ai.latch-minutes", 3) * 60_000) {
                pd.latchMs = 0; pd.latchFlagged = false; pd.latchFloor = 0; pd.cusum = 0;
            } else {
                pd.latchFloor = Math.max(pd.latchFloor, Math.min(pd.cusum, m.cusumH));
                pd.cusum = Math.max(pd.cusum, pd.latchFloor);
            }
        } else if (pd.cusum >= base) {
            pd.latchMs = now;
            pd.latchFloor = base;
        }
        int pct = (int) Math.min(100, Math.round(pd.cusum * 100 / m.cusumH));
        if (pct >= cfg.getInt("ai.show-from-percent", 99)) plugin.warn(p, pct);
        pd.probs.addLast(prob);
        while (pd.probs.size() > Model.CONFIRM_N) pd.probs.removeFirst();
        if (pd.cusum >= m.cusumH) {
            // onay kapisi: su an da gercekten supheli gorunmeli (eski kanitla flag atilmaz)
            double avg = pd.probs.stream().mapToDouble(Double::doubleValue).average().orElse(0);
            // tekrar eden flag'lerde kapi daha siki (ilk flag sonrasi hizli akis yanlis alarma donusmesin)
            double gate = pd.latchFlagged ? Math.max(m.confirmProb, cfg.getDouble("ai.repeat-confirm-prob", 0.9)) : m.confirmProb;
            if (pd.probs.size() < Model.CONFIRM_N || avg < gate) { pd.cusum = m.cusumH; return; }
            // flag sonrasi kanit hemen kilit seviyesine doner (sifirdan baslamaz)
            pd.cusum = base;
            pd.latchFloor = base;
            pd.latchMs = now;
            pd.latchFlagged = true;
            // probs temizlenmez: hile devam ediyorsa onay kapisi hemen gecilir ve sonraki log hizlica gelir
            plugin.flag(p, "Aim (AI)", plugin.getConfig().getDouble("ai.vl-per-flag", 2.0),
                    String.format("son guven=%%%.0f", prob * 100));
        }
    }

    /**
     * Kayit: her vurusta, son ornekten en az record-interval-ms gectiyse ve pencere "gercek dovus" kalitesindeyse
     * (dolu bakis penceresi, hedef takibi, bakis hareketi) 1 HAM ornek alinir. Kalitesiz pencereler alinmaz ve nedeni yazilir.
     */
    private void record(Player p, PlayerData pd, long now) {
        pd.recHits++;
        var cfg = plugin.getConfig();
        long gap = cfg.getLong("ai.record-interval-ms", 2000);
        boolean taken = false;
        if (now - pd.lastSampleMs >= gap) {
            double[][] rawRows = pd.rawWindow();
            if (rawRows == null) {
                pd.recWhy = "bakis verisi dolmadi (fareyi hareket ettir)";
            } else {
                double[] f = Features.compute(rawRows, Features.V3);
                if (f[15] < cfg.getDouble("ai.record-min-target-fraction", 0.5)) {
                    pd.recWhy = "hedefi takip et (bakis hedefte degil)";
                } else if (f[0] + f[3] < cfg.getDouble("ai.record-min-activity", 0.3)) {
                    pd.recWhy = "fareyi hareket ettir (bakis cok durgun)";
                } else {
                    plugin.recordSample(pd.recordLabel, pd.sessionId, rawRows, f, p.getName());
                    pd.recSamples++;
                    pd.lastSampleMs = now;
                    pd.recWhy = null;
                    taken = true;
                }
            }
        }
        showRecord(p, pd, taken);
    }

    private void showRecord(Player p, PlayerData pd, boolean taken) {
        int target = Math.max(1, plugin.getConfig().getInt("ai.min-samples-per-class", 30));
        int pct = Math.min(100, pd.recSamples * 100 / target);
        String quality = pd.recSamples >= target * 2 ? "cok iyi egitilir"
                : pd.recSamples >= target ? "yeterli, egitilebilir" : "az";
        var color = pd.recordLabel.equals("cheat") ? net.kyori.adventure.text.format.NamedTextColor.RED
                : net.kyori.adventure.text.format.NamedTextColor.GREEN;
        String text = "[" + pd.recordLabel + "] vurus: " + pd.recHits + " | ornek: " + pd.recSamples + "/" + target
                + " (%" + pct + ") " + quality + (taken ? " +1" : "");
        // bakis verisi yetersizse nedenini goster (hareket/fare etmeden ornek alinamaz)
        if (!taken && pd.recWhy != null) text += " | " + pd.recWhy;
        var title = net.kyori.adventure.title.Title.title(
                net.kyori.adventure.text.Component.empty(),
                net.kyori.adventure.text.Component.text(text, color),
                net.kyori.adventure.title.Title.Times.times(java.time.Duration.ZERO,
                        java.time.Duration.ofMillis(1500), java.time.Duration.ofMillis(250)));
        p.showTitle(title);
        if (pd.recorder != null) {
            Player r = org.bukkit.Bukkit.getPlayer(pd.recorder);
            if (r != null && r != p) r.showTitle(net.kyori.adventure.title.Title.title(
                    net.kyori.adventure.text.Component.empty(),
                    net.kyori.adventure.text.Component.text(p.getName() + " " + text,
                            net.kyori.adventure.text.format.NamedTextColor.YELLOW),
                    net.kyori.adventure.title.Title.Times.times(java.time.Duration.ZERO,
                            java.time.Duration.ofMillis(1500), java.time.Duration.ofMillis(250))));
        }
    }

    /** Elytra + hedefe kilitlenme (ElytraTarget): havada ucarken bakis surekli hedefin tam ustunde. */
    private void elytraTarget(Player p, PlayerData pd) {
        var cfg = plugin.getConfig();
        if (!cfg.getBoolean("checks.elytra-target.enabled", true)) return;
        double[] f = pd.features();
        if (f == null) return;
        boolean bad = f[15] >= 0.6 && f[20] >= cfg.getDouble("checks.elytra-target.lock-fraction", 0.92)
                && f[16] < cfg.getDouble("checks.elytra-target.max-mean-error", 2.5);
        if (buffer(pd, "elytra", bad, cfg.getDouble("checks.elytra-target.buffer", 3))) {
            plugin.flag(p, "Elytra (Hedef)", cfg.getDouble("checks.elytra-target.vl", 2.0),
                    String.format("kilit=%%%.0f ort.hata=%.1f", f[20] * 100, f[16]));
        }
    }

    /** Ihlal tamponu: tek seferlik gurultu flag atmaz; ardisik/tekrarlayan ihlal gerekir. */
    private boolean buffer(PlayerData pd, String key, boolean bad, double need) {
        double v = pd.buf.merge(key, bad ? 1.0 : -0.5, Double::sum);
        if (v < 0) { pd.buf.put(key, 0.0); return false; }
        if (bad && v >= need) { pd.buf.put(key, 0.0); return true; }
        return false;
    }

    private static double to0(Vector eyeV, BoundingBox box) {
        return box.getCenter().distance(eyeV);
    }

    private void auraChecks(Player p, LivingEntity t, PlayerData pd, long now) {
        var cfg = plugin.getConfig();
        Location eye = p.getEyeLocation();
        BoundingBox box = t.getBoundingBox();
        Vector eyeV = eye.toVector();

        if (cfg.getBoolean("checks.aura-reach.enabled", true)) {
            Vector near = new Vector(
                    Math.max(box.getMinX(), Math.min(eyeV.getX(), box.getMaxX())),
                    Math.max(box.getMinY(), Math.min(eyeV.getY(), box.getMaxY())),
                    Math.max(box.getMinZ(), Math.min(eyeV.getZ(), box.getMaxZ())));
            double dist = near.distance(eyeV);
            double maxReach = cfg.getDouble("checks.aura-reach.max-reach", 3.8) + p.getPing() * 0.004 + (p.isGliding() ? 1.5 : 0); // elytra hizinda sunucu konumu geride kalir
            boolean bad = dist > maxReach;
            if (buffer(pd, "reach", bad, cfg.getDouble("checks.aura-reach.buffer", 4))) {
                plugin.flag(p, "Aura (Reach)", cfg.getDouble("checks.aura-reach.vl", 1.0), String.format("mesafe=%.2f", dist));
            }
        }

        if (cfg.getBoolean("checks.aura-angle.enabled", true)) {
            Vector to = box.getCenter().subtract(eyeV);
            if (to.lengthSquared() > 2.25) { // 1.5 blok icindekileri atla
                // bakis isini genisletilmis kutuya degiyorsa hedefe bakiyordur (buyuk/hareketli mobler icin)
                boolean looking = box.clone().expand(0.35).rayTrace(eyeV, eye.getDirection(), 8) != null;
                double angle = Math.toDegrees(eye.getDirection().angle(to));
                boolean bad = !looking && angle > cfg.getDouble("checks.aura-angle.max-angle", 80.0);
                if (buffer(pd, "angle", bad, cfg.getDouble("checks.aura-angle.buffer", 3))) {
                    plugin.flag(p, "Aura (Aci)", cfg.getDouble("checks.aura-angle.vl", 1.0), String.format("aci=%.0f", angle));
                }
            }
        }

        if (cfg.getBoolean("checks.aura-wall.enabled", true) && to0(eyeV, box) > 1.2) {
            // goz, govde merkezi ve ayaklardan hicbiri gorunmuyorsa (kose/cit/cam gibi sinirlarda yanlis alarm olmasin)
            Location eyeL = p.getEyeLocation();
            Vector[] pts = {t.getEyeLocation().toVector(), box.getCenter(), new Vector(box.getCenterX(), box.getMinY() + 0.2, box.getCenterZ())};
            boolean bad = true;
            for (Vector pt : pts) {
                Vector dir = pt.clone().subtract(eyeL.toVector());
                double len = dir.length();
                if (len < 0.01 || p.getWorld().rayTraceBlocks(eyeL, dir.normalize(), len, org.bukkit.FluidCollisionMode.NEVER, true) == null) { bad = false; break; }
            }
            if (buffer(pd, "wall", bad, cfg.getDouble("checks.aura-wall.buffer", 6))) {
                plugin.flag(p, "Aura (Duvar)", cfg.getDouble("checks.aura-wall.vl", 1.5), "gorus hatti engelli");
            }
        }

        if (cfg.getBoolean("checks.aura-multi.enabled", true)) {
            long win = cfg.getLong("checks.aura-multi.window-ms", 200);
            pd.recentTargets.values().removeIf(ts -> now - ts > win);
            pd.recentTargets.put(t.getUniqueId(), now);
            if (pd.recentTargets.size() >= cfg.getInt("checks.aura-multi.min-targets", 4)) {
                pd.recentTargets.clear();
                plugin.flag(p, "Aura (Multi)", cfg.getDouble("checks.aura-multi.vl", 1.5),
                        "kisa surede cok hedef");
            }
        }
    }
}
