package net.bloodac;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Topluluk modeli: K-fold egitilmis kucuk sinir aglari (n -> H tanh -> 1) + gradyan artirmali agaclar (GBDT),
 * logit duzeyinde ortalama, Platt kalibrasyonu. Oturum (grup) bazli capraz dogrulama: ayni oturumun pencereleri
 * hem egitimde hem testte olmaz, bu yuzden raporlanan basari gercege yakindir.
 * Cikis: kalibre P(hile) (sinif dengeli: 0.5 = esit kanit).
 */
public final class Model {
    static final int H = 12;
    static final int FOLDS = 5;

    public final int n;
    public final double[] mu, sigma;
    private final Net[] nets;
    private Gbdt[] gbs;                 // null = eski (yalniz sinir agi) model
    private double calA = 1, calB = 0;  // Platt: p = sigmoid(a*s + b)
    /** Egitimde legit pencerelerin %99'unu gecen guven esigi onerisi. */
    public double threshold = 0.9;
    /** CUSUM: kanit = max(0, kanit + logit(p) - k); kanit >= h olunca flag. */
    public double cusumK = 1.0, cusumH = 15.0;
    /** Temiz (negatif) pencerelerin kaniti dusurme agirligi: 1 = simetrik, <1 = kanit daha yavas silinir. */
    public double cleanWeight = 1.0;
    /** Flag icin kanit esigine ek olarak son CONFIRM_N pencerenin ortalamasi bu degerin ustunde olmali. */
    public double confirmProb = 0.0;
    public static final int CONFIRM_N = 4;

    private static final class Net {
        final double[][] w1 = new double[H][];
        final double[] b1 = new double[H], w2 = new double[H];
        double b2;

        Net(int n, Random r) {
            double s = 1.0 / Math.sqrt(n);
            for (int j = 0; j < H; j++) {
                w1[j] = new double[n];
                for (int i = 0; i < n; i++) w1[j][i] = r.nextGaussian() * s;
                w2[j] = r.nextGaussian() * 0.3;
            }
        }

        Net copy() {
            Net c = new Net(w1[0].length, new Random(0));
            for (int j = 0; j < H; j++) {
                System.arraycopy(w1[j], 0, c.w1[j], 0, w1[j].length);
                c.b1[j] = b1[j];
                c.w2[j] = w2[j];
            }
            c.b2 = b2;
            return c;
        }

        double logit(double[] x, double[] h) {
            double z = b2;
            for (int j = 0; j < H; j++) {
                double a = b1[j];
                double[] w = w1[j];
                for (int i = 0; i < w.length; i++) a += w[i] * x[i];
                h[j] = Math.tanh(a);
                z += w2[j] * h[j];
            }
            return z;
        }

        double forward(double[] x, double[] h) { return 1.0 / (1.0 + Math.exp(-logit(x, h))); }
    }

    private Model(int n, Net[] nets) {
        this.n = n;
        this.nets = nets;
        mu = new double[n];
        sigma = new double[n];
    }

    private double[] standardize(double[] raw) {
        double[] x = new double[n];
        for (int i = 0; i < n; i++) x[i] = clamp((raw[i] - mu[i]) / sigma[i]);
        return x;
    }

    /** Ensemble logit'i (kalibrasyon oncesi). */
    private double blendLogit(double[] raw, double[] z, int[] only) {
        double[] h = new double[H];
        double sm = 0;
        int c = 0;
        for (int f = 0; f < nets.length; f++) {
            if (only != null && f != only[0]) continue;
            sm += nets[f].logit(z, h); c++;
        }
        sm /= Math.max(1, c);
        if (gbs == null) return sm;
        double sg = 0;
        c = 0;
        for (int f = 0; f < gbs.length; f++) {
            if (only != null && f != only[0]) continue;
            sg += gbs[f].predictRaw(raw); c++;
        }
        sg /= Math.max(1, c);
        return 0.5 * (sm + sg);
    }

    public double predict(double[] raw) {
        double[] z = standardize(raw);
        if (gbs == null) {
            double[] h = new double[H];
            double s = 0;
            for (Net net : nets) s += net.forward(z, h);
            return s / nets.length;
        }
        return sigmoid(calA * blendLogit(raw, z, null) + calB);
    }

    private static double sigmoid(double v) { return 1.0 / (1.0 + Math.exp(-v)); }
    private static double clamp(double v) { return Math.max(-6, Math.min(6, v)); }

    public static final class Report {
        public double accuracy, precision, recall, falsePositiveRate, falsePer1000, meanDetect, auc;
        public double[] oof, labels;
        public int legit, cheat, n, groups;
        public List<String> topFeatures = new ArrayList<>();
    }

    /** Eski API: ozellik listeleri (gruplama yok). */
    public static Model train(List<double[]> legit, List<double[]> cheat, int n, Report rep,
                              double targetFalsePer1000, double margin, double cleanWeight, double minEvidence, double confirmProb) {
        int total = legit.size() + cheat.size();
        double[][] X = new double[total][];
        double[] y = new double[total];
        int[] g = new int[total];
        int k = 0;
        for (double[] x : legit) { X[k] = x; y[k] = 0; g[k++] = -1; }
        for (double[] x : cheat) { X[k] = x; y[k] = 1; g[k++] = -1; }
        return train(X, y, g, n, rep, targetFalsePer1000, margin, cleanWeight, minEvidence, confirmProb, null);
    }

    /**
     * @param group oturum kimligi (>=0) veya -1 (grupsuz: her satir kendi basina). Ayni grup ayni fold'a girer.
     * @param names ozellik adlari (onem raporu icin) veya null
     */
    public static Model train(double[][] X0, double[] y, int[] group, int n, Report rep,
                              double targetFalsePer1000, double margin, double cleanWeight, double minEvidence,
                              double confirmProb, String[] names) {
        int total = X0.length;
        double[][] xs = new double[total][];
        int legitN = 0, cheatN = 0;
        for (int i = 0; i < total; i++) {
            xs[i] = java.util.Arrays.copyOf(X0[i], n);
            if (y[i] == 1) cheatN++; else legitN++;
        }

        Model m = new Model(n, new Net[FOLDS]);
        m.gbs = new Gbdt[FOLDS];
        for (int i = 0; i < n; i++) {
            double s = 0;
            for (double[] x : xs) s += x[i];
            m.mu[i] = s / total;
            double v = 0;
            for (double[] x : xs) v += Math.pow(x[i] - m.mu[i], 2);
            m.sigma[i] = Math.max(Math.sqrt(v / total), 1e-6);
        }
        double[][] z = new double[total][n];
        for (int a = 0; a < total; a++) for (int i = 0; i < n; i++) z[a][i] = clamp((xs[a][i] - m.mu[i]) / m.sigma[i]);

        Random rnd = new Random(42);
        int[] fold = assignFolds(y, group, rnd);
        double[] w = sampleWeights(y, group, total);
        double wl = total / (2.0 * legitN), wc = total / (2.0 * cheatN);

        // ---- fold basina SA + GBDT; out-of-fold logit'ler ----
        double[] oofS = new double[total];
        double[] h = new double[H];
        Gbdt.Params gp = new Gbdt.Params();
        if (total < 400) { gp.rounds = 80; gp.minLeaf = 4; }
        for (int f = 0; f < FOLDS; f++) {
            m.nets[f] = trainNet(z, y, fold, f, n, wl, wc, new Random(100 + f));
            int tr = 0;
            for (int a = 0; a < total; a++) if (fold[a] != f) tr++;
            double[][] gx = new double[tr][];
            double[] gy = new double[tr], gw = new double[tr];
            int q = 0;
            for (int a = 0; a < total; a++) if (fold[a] != f) { gx[q] = xs[a]; gy[q] = y[a]; gw[q] = w[a]; q++; }
            m.gbs[f] = Gbdt.train(gx, gy, gw, n, gp, new Random(200 + f));
            for (int a = 0; a < total; a++) {
                if (fold[a] != f) continue;
                oofS[a] = 0.5 * (m.nets[f].logit(z[a], h) + m.gbs[f].predictRaw(xs[a]));
            }
        }

        // ---- Platt kalibrasyonu (sinif dengeli) ----
        double[] ab = platt(oofS, y, wl, wc);
        m.calA = ab[0];
        m.calB = ab[1];
        double[] oof = new double[total];
        for (int a = 0; a < total; a++) oof[a] = sigmoid(m.calA * oofS[a] + m.calB);

        int tp = 0, fp = 0, tn = 0, fn = 0;
        List<Double> legitP = new ArrayList<>(), cheatP = new ArrayList<>();
        for (int a = 0; a < total; a++) {
            boolean pred = oof[a] >= 0.5;
            if (y[a] == 1) { cheatP.add(oof[a]); if (pred) tp++; else fn++; }
            else { legitP.add(oof[a]); if (pred) fp++; else tn++; }
        }
        rep.n = n; rep.legit = legitN; rep.cheat = cheatN;
        rep.oof = oof; rep.labels = y;
        rep.accuracy = (tp + tn) / (double) total;
        rep.precision = tp + fp == 0 ? 1 : tp / (double) (tp + fp);
        rep.recall = tp + fn == 0 ? 0 : tp / (double) (tp + fn);
        rep.falsePositiveRate = fp + tn == 0 ? 0 : fp / (double) (fp + tn);
        rep.auc = auc(oof, y);
        java.util.Set<Integer> gs = new java.util.HashSet<>();
        for (int g : group) if (g >= 0) gs.add(g);
        rep.groups = gs.size();
        Collections.sort(legitP);
        double p99 = legitP.get(Math.min(legitP.size() - 1, (int) Math.floor(legitP.size() * 0.99)));
        m.threshold = Math.max(0.5, Math.min(0.995, p99 + 0.005));
        m.cleanWeight = Math.max(0.05, Math.min(1, cleanWeight));
        m.confirmProb = Math.max(0, Math.min(0.99, confirmProb));
        m.calibrate(legitP, cheatP, targetFalsePer1000, margin, minEvidence, rep);

        if (names != null) importance(m, z, xs, y, fold, names, rep);
        return m;
    }

    /** Sinif bazli, grup butunlugunu koruyan fold atamasi. */
    private static int[] assignFolds(double[] y, int[] group, Random rnd) {
        int total = y.length;
        java.util.Map<Integer, List<Integer>> groups = new java.util.LinkedHashMap<>();
        int solo = -2;
        for (int i = 0; i < total; i++) {
            int g = group[i] >= 0 ? group[i] : solo--;
            groups.computeIfAbsent(g, k -> new ArrayList<>()).add(i);
        }
        List<List<Integer>> list = new ArrayList<>(groups.values());
        Collections.shuffle(list, rnd);
        list.sort((a, b) -> Integer.compare(b.size(), a.size()));
        int[][] load = new int[FOLDS][2];
        int[] fold = new int[total];
        for (List<Integer> g : list) {
            int cls = 0;
            for (int i : g) cls += y[i] == 1 ? 1 : -1;
            int c = cls > 0 ? 1 : 0;
            int best = 0;
            for (int f = 1; f < FOLDS; f++) if (load[f][c] < load[best][c]) best = f;
            for (int i : g) { fold[i] = best; load[best][y[i] == 1 ? 1 : 0]++; }
        }
        return fold;
    }

    /** Sinif dengesi + buyuk oturumlarin baskin olmamasi (1/sqrt(grup boyu)); sinif toplam agirligi total/2. */
    private static double[] sampleWeights(double[] y, int[] group, int total) {
        java.util.Map<Integer, Integer> size = new java.util.HashMap<>();
        for (int g : group) if (g >= 0) size.merge(g, 1, Integer::sum);
        double[] w = new double[total];
        double[] sum = new double[2];
        for (int i = 0; i < total; i++) {
            w[i] = group[i] >= 0 ? 1.0 / Math.sqrt(size.get(group[i])) : 1.0;
            sum[y[i] == 1 ? 1 : 0] += w[i];
        }
        for (int i = 0; i < total; i++) w[i] *= (total / 2.0) / sum[y[i] == 1 ? 1 : 0];
        return w;
    }

    private static double[] platt(double[] s, double[] y, double wl, double wc) {
        double a = 1, b = 0;
        for (int it = 0; it < 300; it++) {
            double ga = 0, gb = 0, haa = 1e-6, hab = 0, hbb = 1e-6;
            for (int i = 0; i < s.length; i++) {
                double w = y[i] == 1 ? wc : wl;
                double p = sigmoid(a * s[i] + b);
                double r = (p - y[i]) * w, hh = p * (1 - p) * w;
                ga += r * s[i]; gb += r;
                haa += hh * s[i] * s[i]; hab += hh * s[i]; hbb += hh;
            }
            double det = haa * hbb - hab * hab;
            if (Math.abs(det) < 1e-12) break;
            double da = (hbb * ga - hab * gb) / det, db = (haa * gb - hab * ga) / det;
            a -= Math.max(-1, Math.min(1, da));
            b -= Math.max(-1, Math.min(1, db));
            if (Math.abs(da) + Math.abs(db) < 1e-7) break;
        }
        return new double[]{a, b};
    }

    static double auc(double[] p, double[] y) {
        Integer[] idx = new Integer[p.length];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        java.util.Arrays.sort(idx, (u, v) -> Double.compare(p[u], p[v]));
        double rs = 0;
        int np = 0, nn = 0;
        for (int r = 0; r < idx.length; r++) { if (y[idx[r]] == 1) { rs += r + 1; np++; } else nn++; }
        return np == 0 || nn == 0 ? 0.5 : (rs - np * (np + 1) / 2.0) / (np * (double) nn);
    }

    /** Permutasyon onemi: bir ozellik karistirilinca held-out AUC ne kadar dusuyor. */
    private static void importance(Model m, double[][] z, double[][] xs, double[] y, int[] fold, String[] names, Report rep) {
        int n = m.n, total = z.length;
        double[] drop = new double[n];
        Random r = new Random(5);
        for (int f = 0; f < FOLDS; f++) {
            List<Integer> rows = new ArrayList<>();
            for (int a = 0; a < total; a++) if (fold[a] == f) rows.add(a);
            if (rows.size() < 10) continue;
            double[] yy = new double[rows.size()];
            for (int i = 0; i < yy.length; i++) yy[i] = y[rows.get(i)];
            double base = foldAuc(m, f, rows, z, xs, yy, -1, null);
            for (int j = 0; j < n; j++) {
                List<Integer> perm = new ArrayList<>(rows);
                Collections.shuffle(perm, r);
                drop[j] += base - foldAuc(m, f, rows, z, xs, yy, j, perm);
            }
        }
        Integer[] order = new Integer[n];
        for (int i = 0; i < n; i++) order[i] = i;
        java.util.Arrays.sort(order, (u, v) -> Double.compare(drop[v], drop[u]));
        for (int i = 0; i < Math.min(8, n); i++) {
            if (drop[order[i]] <= 0) break;
            rep.topFeatures.add(String.format("%s (%.3f)", names[order[i]], drop[order[i]] / FOLDS));
        }
    }

    private static double foldAuc(Model m, int f, List<Integer> rows, double[][] z, double[][] xs, double[] yy, int col, List<Integer> perm) {
        double[] p = new double[rows.size()];
        double[] h = new double[H];
        for (int i = 0; i < p.length; i++) {
            int a = rows.get(i);
            double[] zz = z[a], xx = xs[a];
            if (col >= 0) {
                int src = perm.get(i);
                zz = z[a].clone(); xx = xs[a].clone();
                zz[col] = z[src][col]; xx[col] = xs[src][col];
            }
            p[i] = 0.5 * (m.nets[f].logit(zz, h) + m.gbs[f].predictRaw(xx));
        }
        return auc(p, yy);
    }

    public double step(double p) {
        p = Math.min(0.995, Math.max(0.005, p));
        double l = Math.log(p / (1 - p)) - cusumK;
        return l < 0 ? l * cleanWeight : l;
    }

    /** h'yi, legit pencerelerle simule edilen yanlis flag hizi hedefin altinda kalacak sekilde secer. */
    private void calibrate(List<Double> legitP, List<Double> cheatP, double target, double margin, double minEvidence, Report rep) {
        double chosen = 40;
        for (double hh = 2; hh <= 40; hh += 0.5) {
            if (falsePer1000(legitP, hh, new Random(7)) <= target) { chosen = hh; break; }
        }
        cusumH = Math.max(minEvidence, chosen) * Math.max(1, margin);
        rep.falsePer1000 = falsePer1000(legitP, cusumH, new Random(8));
        rep.meanDetect = meanDetect(cheatP, cusumH, new Random(9));
    }

    private double falsePer1000(List<Double> legitP, double hh, Random r) {
        int steps = 30000, c = 0;
        double s = 0;
        double[] ring = new double[CONFIRM_N];
        for (int i = 0; i < steps; i++) {
            double p = legitP.get(r.nextInt(legitP.size()));
            ring[i % CONFIRM_N] = p;
            s = Math.max(0, s + step(p));
            if (s >= hh) {
                if (i >= CONFIRM_N && avg(ring) >= confirmProb) { c++; s = 0; } else s = hh;
            }
        }
        return c * 1000.0 / steps;
    }

    private static double avg(double[] a) {
        double s = 0;
        for (double v : a) s += v;
        return s / a.length;
    }

    private double meanDetect(List<Double> cheatP, double hh, Random r) {
        if (cheatP.isEmpty()) return 0;
        int trials = 2000;
        double sum = 0;
        for (int t = 0; t < trials; t++) {
            double s = 0;
            int n = 0;
            double[] ring = new double[CONFIRM_N];
            while (n < 300) {
                n++;
                double p = cheatP.get(r.nextInt(cheatP.size()));
                ring[n % CONFIRM_N] = p;
                s = Math.max(0, s + step(p));
                if (s >= hh) {
                    if (n >= CONFIRM_N && avg(ring) >= confirmProb) break;
                    s = hh;
                }
            }
            sum += n;
        }
        return sum / trials;
    }

    private static Net trainNet(double[][] z, double[] ys, int[] fold, int val, int n,
                                double wl, double wc, Random rnd) {
        int total = z.length;
        Net net = new Net(n, rnd);
        Net best = net.copy();
        double bestLoss = Double.MAX_VALUE, lr = 0.03, l2 = 1e-3;
        int bad = 0;
        int[] tr = java.util.stream.IntStream.range(0, total).filter(a -> fold[a] != val).toArray();
        double[] h = new double[H], x = new double[n];
        for (int epoch = 0; epoch < 600 && bad < 10; epoch++) {
            for (int i = tr.length - 1; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = tr[i]; tr[i] = tr[j]; tr[j] = t; }
            for (int a : tr) {
                for (int i = 0; i < n; i++) x[i] = z[a][i] + rnd.nextGaussian() * 0.05; // gurultu ile augmentasyon
                double p = net.forward(x, h);
                double g = (p - ys[a]) * (ys[a] == 1 ? wc : wl);
                for (int j = 0; j < H; j++) {
                    double dpre = g * net.w2[j] * (1 - h[j] * h[j]);
                    net.w2[j] -= lr * (g * h[j] + l2 * net.w2[j]);
                    double[] w = net.w1[j];
                    for (int i = 0; i < n; i++) w[i] -= lr * (dpre * x[i] + l2 * w[i]);
                    net.b1[j] -= lr * dpre;
                }
                net.b2 -= lr * g;
            }
            lr = Math.max(0.003, lr * 0.995);
            if (epoch % 5 == 4) {
                double loss = 0;
                int c = 0;
                for (int a = 0; a < total; a++) {
                    if (fold[a] != val) continue;
                    double p = Math.min(1 - 1e-9, Math.max(1e-9, net.forward(z[a], h)));
                    loss += -(ys[a] == 1 ? wc * Math.log(p) : wl * Math.log(1 - p));
                    c++;
                }
                loss /= Math.max(1, c);
                if (loss < bestLoss - 1e-4) { bestLoss = loss; best = net.copy(); bad = 0; } else bad++;
            }
        }
        return best;
    }

    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        o.addProperty("v", gbs != null ? 3 : 2);
        o.addProperty("n", n);
        o.addProperty("threshold", threshold);
        o.addProperty("k", cusumK);
        o.addProperty("h", cusumH);
        o.addProperty("cw", cleanWeight);
        o.addProperty("cp", confirmProb);
        o.add("mu", arr(mu));
        o.add("sigma", arr(sigma));
        JsonArray ns = new JsonArray();
        for (Net net : nets) {
            JsonObject j = new JsonObject();
            JsonArray w1 = new JsonArray();
            for (double[] w : net.w1) w1.add(arr(w));
            j.add("w1", w1);
            j.add("b1", arr(net.b1));
            j.add("w2", arr(net.w2));
            j.addProperty("b2", net.b2);
            ns.add(j);
        }
        o.add("nets", ns);
        if (gbs != null) {
            JsonArray g = new JsonArray();
            for (Gbdt t : gbs) g.add(t.toJson());
            o.add("gb", g);
            o.addProperty("ca", calA);
            o.addProperty("cb", calB);
        }
        return o;
    }

    public static Model fromJson(JsonObject o) {
        if (!o.has("v") || o.get("v").getAsInt() < 2) return null;
        int n = o.get("n").getAsInt();
        JsonArray ns = o.getAsJsonArray("nets");
        Net[] nets = new Net[ns.size()];
        Model m = new Model(n, nets);
        m.threshold = o.get("threshold").getAsDouble();
        if (o.has("k")) m.cusumK = o.get("k").getAsDouble();
        if (o.has("h")) m.cusumH = o.get("h").getAsDouble();
        if (o.has("cw")) m.cleanWeight = o.get("cw").getAsDouble();
        if (o.has("cp")) m.confirmProb = o.get("cp").getAsDouble();
        for (int i = 0; i < n; i++) {
            m.mu[i] = o.getAsJsonArray("mu").get(i).getAsDouble();
            m.sigma[i] = o.getAsJsonArray("sigma").get(i).getAsDouble();
        }
        for (int q = 0; q < nets.length; q++) {
            JsonObject j = ns.get(q).getAsJsonObject();
            Net net = new Net(n, new Random(0));
            for (int a = 0; a < H; a++) {
                JsonArray w = j.getAsJsonArray("w1").get(a).getAsJsonArray();
                for (int i = 0; i < n; i++) net.w1[a][i] = w.get(i).getAsDouble();
                net.b1[a] = j.getAsJsonArray("b1").get(a).getAsDouble();
                net.w2[a] = j.getAsJsonArray("w2").get(a).getAsDouble();
            }
            net.b2 = j.get("b2").getAsDouble();
            nets[q] = net;
        }
        if (o.has("gb")) {
            JsonArray g = o.getAsJsonArray("gb");
            m.gbs = new Gbdt[g.size()];
            for (int i = 0; i < m.gbs.length; i++) m.gbs[i] = Gbdt.fromJson(g.get(i).getAsJsonObject());
            m.calA = o.get("ca").getAsDouble();
            m.calB = o.get("cb").getAsDouble();
        }
        return m;
    }

    private static JsonArray arr(double[] a) {
        JsonArray j = new JsonArray();
        for (double d : a) j.add(d);
        return j;
    }
}
