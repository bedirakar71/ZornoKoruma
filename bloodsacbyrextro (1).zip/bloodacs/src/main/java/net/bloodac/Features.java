package net.bloodac;

/**
 * Ozellik cikarimi. Ilk 21 ozellik PlayerData.base21 ile ayni (geriye uyumlu). Gerisi ham pencereden (raw) hesaplanir,
 * bu yuzden ham veri saklandigi surece yeni ozellik eklemek icin yeniden kayit gerekmez.
 *
 * Ham satir: {dyaw, dpitch, hedef merkezine hata, hedef gozune hata, mutlak pitch}
 */
public final class Features {
    private Features() {}

    public static final int BASE = PlayerData.FEATURES;      // 21
    public static final int EXTRA = 25;
    public static final int V3 = BASE + EXTRA;               // 45

    public static final String[] NAMES = {
            "yaw-ort", "yaw-std", "yaw-max", "pitch-ort", "pitch-std", "pitch-max", "yaw-ivme-std", "yaw-ani-donus", "yaw-puruzsuzluk",
            "pitch-ivme-std", "yaw-sifir", "pitch-sifir", "yaw-pitch-korelasyon", "yaw-yon-degisim", "yaw-entropi",
            "hedef-orani", "merkez-hata-ort", "merkez-hata-std", "merkez-hata-min", "merkez-hata-degisim", "merkez-kilit",
            "gcd-uyum", "yaw-carpiklik", "yaw-basiklik", "yaw-ac1", "yaw-ac2", "yaw-ac3", "jerk-ort", "jerk-max", "ayni-deger-orani",
            "ayni-deger-seri", "pitch/yaw-enerji", "buyuk-yon-degisim", "goz-hata-ort", "goz-hata-std", "goz-hata-min", "goz-kilit",
            "hata-egimi", "aktif-oran", "ivme-sinirli-yaw", "ivme-sinirli-pitch", "tepe/ort", "pitch-ort-mutlak", "pitch-aralik",
            "goz-hata-ilk-yarim", "goz-hata-son-yarim"
    };

    /** Ilk n ozelligi dondurur (n <= V3). */
    public static double[] compute(double[][] rows, int n) {
        double[] base = PlayerData.base21(rows);
        if (n <= BASE) return java.util.Arrays.copyOf(base, n);
        double[] all = new double[V3];
        System.arraycopy(base, 0, all, 0, BASE);
        extra(rows, all);
        return java.util.Arrays.copyOf(all, n);
    }

    private static void extra(double[][] d, double[] f) {
        int n = d.length;
        double[] dy = new double[n], dp = new double[n], ay = new double[n], ap = new double[n];
        for (int i = 0; i < n; i++) { dy[i] = d[i][0]; dp[i] = d[i][1]; ay[i] = Math.abs(dy[i]); ap[i] = Math.abs(dp[i]); }
        double my = mean(dy), sy = std(dy), mAy = mean(ay);

        int k = BASE;
        f[k++] = gcdFit(dy, dp);                                   // 21
        f[k++] = sy < 1e-9 ? 0 : moment(dy, my, 3) / Math.pow(sy, 3);   // 22 carpiklik
        f[k++] = sy < 1e-9 ? 0 : moment(dy, my, 4) / Math.pow(sy, 4);   // 23 basiklik
        f[k++] = autocorr(dy, 1);                                  // 24
        f[k++] = autocorr(dy, 2);                                  // 25
        f[k++] = autocorr(dy, 3);                                  // 26

        double jerkSum = 0, jerkMax = 0;
        for (int i = 3; i < n; i++) {
            double j = Math.abs(dy[i] - 3 * dy[i - 1] + 3 * dy[i - 2] - dy[i - 3]);
            jerkSum += j; jerkMax = Math.max(jerkMax, j);
        }
        f[k++] = (jerkSum / Math.max(1, n - 3)) / (mAy + 1e-3);    // 27
        f[k++] = jerkMax;                                          // 28

        int same = 0, run = 1, best = 1;
        for (int i = 1; i < n; i++) {
            boolean eq = Math.abs(dy[i]) > 1e-4 && Math.abs(dy[i] - dy[i - 1]) < 1e-4;
            if (eq) { same++; run++; best = Math.max(best, run); } else run = 1;
        }
        f[k++] = same / (double) (n - 1);                          // 29
        f[k++] = best / (double) n;                                // 30
        double ey = 0, ep = 0;
        for (int i = 0; i < n; i++) { ey += dy[i] * dy[i]; ep += dp[i] * dp[i]; }
        f[k++] = ep / (ey + 1e-6);                                 // 31

        int alt = 0, last = 0;
        for (double v : dy) {
            if (Math.abs(v) >= 3) { int s = v > 0 ? 1 : -1; if (last != 0 && s != last) alt++; last = s; }
        }
        f[k++] = alt / (double) n;                                 // 32

        // goz hatasi istatistikleri (hedef biliniyorsa)
        double[] ee = new double[n];
        int cnt = 0;
        for (double[] r : d) if (r[3] >= 0) ee[cnt++] = r[3];
        if (cnt >= 10) {
            double[] e = java.util.Arrays.copyOf(ee, cnt);
            double mn = Double.MAX_VALUE, lock = 0;
            for (double v : e) { mn = Math.min(mn, v); if (v < 1.0) lock++; }
            f[k++] = mean(e);                                      // 33
            f[k++] = std(e);                                       // 34
            f[k++] = mn;                                           // 35
            f[k++] = lock / cnt;                                   // 36
            int h = cnt / 2;
            double a = mean(java.util.Arrays.copyOfRange(e, 0, h)), b = mean(java.util.Arrays.copyOfRange(e, h, cnt));
            f[k++] = b - a;                                        // 37 egim
        } else {
            k += 5;
        }

        int act = 0;
        for (double v : ay) if (v > 0.3) act++;
        f[k++] = act / (double) n;                                 // 38
        f[k++] = accelFraction(dy, 1.0, 0.25);                     // 39
        f[k++] = accelFraction(dp, 0.4, 0.2);                      // 40
        double mx = 0;
        for (double v : ay) mx = Math.max(mx, v);
        f[k++] = mx / (mAy + 1e-3);                                // 41

        double pm = 0, lo = 1e9, hi = -1e9;
        for (double[] r : d) { pm += Math.abs(r[4]); lo = Math.min(lo, r[4]); hi = Math.max(hi, r[4]); }
        f[k++] = pm / n;                                           // 42
        f[k++] = hi - lo;                                          // 43

        if (cnt >= 10) {
            double[] e = java.util.Arrays.copyOf(ee, cnt);
            int h = cnt / 2;
            f[k++] = mean(java.util.Arrays.copyOfRange(e, 0, h)); // 44
            f[k++] = mean(java.util.Arrays.copyOfRange(e, h, cnt)); // 45 (sinir disi korumali asagida)
        }
        for (int i = 0; i < f.length; i++) if (Double.isNaN(f[i]) || Double.isInfinite(f[i])) f[i] = 0;
    }

    /** Aktif ardisik adimlarin hiz degisimi <= maxJerk olan orani. */
    private static double accelFraction(double[] v, double minSpeed, double maxJerk) {
        int pairs = 0, smooth = 0;
        for (int i = 1; i < v.length; i++) {
            if (Math.abs(v[i]) >= minSpeed && Math.abs(v[i - 1]) >= minSpeed) {
                pairs++;
                if (Math.abs(v[i] - v[i - 1]) <= maxJerk) smooth++;
            }
        }
        return pairs < 5 ? 0 : smooth / (double) pairs;
    }

    private static double[] STEPS;

    /** Fare hassasiyetinden gelen olasi GCD adimlari (sens 0..200%). */
    private static synchronized double[] steps() {
        if (STEPS == null) {
            java.util.List<Double> l = new java.util.ArrayList<>();
            for (int s = 0; s <= 200; s++) {
                double sens = s / 200.0;
                double st = Math.pow(sens * 0.6 + 0.2, 3) * 1.2;
                if (st >= 0.02) l.add(st);
            }
            STEPS = l.stream().mapToDouble(Double::doubleValue).toArray();
        }
        return STEPS;
    }

    /** Sifir olmayan delta'larin, en uygun fare adiminin tam kati olma orani (insan = ~1, GCD'siz hile = dusuk). */
    static double gcdFit(double[] dy, double[] dp) {
        int total = 0;
        double[] all = new double[dy.length + dp.length];
        for (double v : dy) if (Math.abs(v) > 1e-4) all[total++] = Math.abs(v);
        for (double v : dp) if (Math.abs(v) > 1e-4) all[total++] = Math.abs(v);
        if (total < 8) return 1;
        double best = 0;
        for (double st : steps()) {
            int ok = 0;
            for (int i = 0; i < total; i++) {
                double q = all[i] / st;
                if (Math.abs(q - Math.rint(q)) * st < 0.0015) ok++;
            }
            best = Math.max(best, ok / (double) total);
            if (best > 0.999) break;
        }
        return best;
    }

    private static double autocorr(double[] a, int lag) {
        double m = mean(a), num = 0, den = 0;
        for (int i = 0; i < a.length; i++) den += (a[i] - m) * (a[i] - m);
        for (int i = lag; i < a.length; i++) num += (a[i] - m) * (a[i - lag] - m);
        return den < 1e-9 ? 0 : num / den;
    }

    private static double moment(double[] a, double m, int p) {
        double s = 0;
        for (double v : a) s += Math.pow(v - m, p);
        return s / a.length;
    }

    private static double mean(double[] a) {
        if (a.length == 0) return 0;
        double s = 0;
        for (double v : a) s += v;
        return s / a.length;
    }

    private static double std(double[] a) {
        double m = mean(a), s = 0;
        for (double v : a) s += (v - m) * (v - m);
        return a.length == 0 ? 0 : Math.sqrt(s / a.length);
    }
}
