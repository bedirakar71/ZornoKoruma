package net.bloodac;

import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class BloodCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUB = List.of("egit", "kayit", "veri", "loglar", "bilgi", "sifirla", "animasyon", "alerts", "durum", "reload");
    private final BloodAC plugin;

    public BloodCommand(BloodAC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("bloodac.admin")) { s.sendMessage(plugin.prefix() + "§cYetkin yok."); return true; }
        String pre = plugin.prefix();
        if (a.length == 0) {
            s.sendMessage(pre + "§7/bloodac §fegit §8- §7AI'yi veritabanindaki orneklerle egit");
            s.sendMessage(pre + "§7/bloodac §fkayit <oyuncu> <legit|cheat|dur> §8- §7ornek topla");
            s.sendMessage(pre + "§7/bloodac §fveri §8- §7veri seti ozeti (eski + ham, oturum sayisi)");
            s.sendMessage(pre + "§7/bloodac §floglar <oyuncu> §8- §7son ihlaller");
            s.sendMessage(pre + "§7/bloodac §fbilgi <oyuncu> §8| §fsifirla <oyuncu> §8| §fanimasyon <oyuncu> §7(test)");
            s.sendMessage(pre + "§7/bloodac §falerts §8- §7uyarilari ac/kapat");
            s.sendMessage(pre + "§7/bloodac §fdurum §8| §freload");
            return true;
        }
        switch (a[0].toLowerCase(java.util.Locale.ROOT)) {
            case "egit", "train" -> plugin.train(s);
            case "kayit", "record" -> record(s, a);
            case "veri", "data" -> plugin.datasetSummary().forEach(line -> s.sendMessage(pre + line));
            case "loglar", "logs" -> logs(s, a);
            case "bilgi", "info" -> {
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null;
                if (t == null) { s.sendMessage(pre + "§c/bloodac bilgi <oyuncu> (cevrimici olmali)"); return true; }
                PlayerData pd = plugin.data(t);
                var m = plugin.model();
                s.sendMessage(pre + "§f" + t.getName() + " §7ping: §f" + t.getPing()
                        + " §7| AI kaniti: §f" + String.format("%.1f", pd.cusum) + (m != null ? "/" + String.format("%.1f", m.cusumH) : ""));
                if (pd.vl.isEmpty()) s.sendMessage(pre + "§7VL yok.");
                pd.vl.forEach((k, v) -> s.sendMessage(pre + "§7" + k + ": §c" + String.format("%.1f", v)));
            }
            case "sifirla", "reset" -> {
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null;
                if (t == null) { s.sendMessage(pre + "§c/bloodac sifirla <oyuncu>"); return true; }
                PlayerData pd = plugin.data(t);
                pd.vl.clear(); pd.buf.clear(); pd.cusum = 0; pd.latchMs = 0; pd.latchFloor = 0; pd.latchFlagged = false; pd.probs.clear();
                s.sendMessage(pre + "§a" + t.getName() + " sifirlandi.");
            }
            case "animasyon", "animation" -> {
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : (s instanceof Player sp ? sp : null);
                if (t == null) { s.sendMessage(pre + "§c/bloodac animasyon <oyuncu> (test: esya birakmaz, atmaz)"); return true; }
                if (plugin.animation() == null) { s.sendMessage(pre + "§cAnimasyon dosyasi yuklenemedi (punish.animation-file)."); return true; }
                Animation.play(plugin, t, plugin.animation(), true, null);
                s.sendMessage(pre + "§a" + t.getName() + " icin animasyon testi basladi.");
            }
            case "alerts" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Sadece oyuncu."); return true; }
                UUID u = p.getUniqueId();
                if (!plugin.alertsOff().remove(u)) { plugin.alertsOff().add(u); s.sendMessage(pre + "§cUyarilar kapali."); }
                else s.sendMessage(pre + "§aUyarilar acik.");
            }
            case "durum", "status" -> {
                s.sendMessage(pre + "§7Veritabani: " + (plugin.db() != null ? "§abagli" : "§ckapali"));
                s.sendMessage(pre + "§7AI modeli: " + plugin.modelInfo());
            }
            case "reload" -> { plugin.setup(); s.sendMessage(pre + "§aYenilendi."); }
            default -> s.sendMessage(pre + "§cBilinmeyen alt komut.");
        }
        return true;
    }

    private void record(CommandSender s, String[] a) {
        String pre = plugin.prefix();
        if (a.length < 2) { s.sendMessage(pre + "§c/bloodac kayit <oyuncu> <legit|cheat|dur>"); return; }
        Player t = Bukkit.getPlayerExact(a[1]);
        if (t == null) { s.sendMessage(pre + "§cOyuncu cevrimdisi."); return; }
        String mode = a.length > 2 ? a[2].toLowerCase(java.util.Locale.ROOT) : "";
        PlayerData pd = plugin.data(t);
        switch (mode) {
            case "legit", "cheat" -> { pd.recordLabel = mode; pd.sessionId = (int) (((System.currentTimeMillis() / 1000) * 31 + t.getName().hashCode()) & 0x7fffffff); pd.recWhy = null; pd.recHits = 0; pd.recSamples = 0; pd.recProgress = 0; pd.lastSampleMs = 0; pd.recorder = (s instanceof Player sp) ? sp.getUniqueId() : null; s.sendMessage(pre + "§a" + t.getName() + " icin '" + mode + "' kaydi basladi (vurus yaptikca ornek alinir)."); }
            case "dur", "stop" -> { pd.recordLabel = null; s.sendMessage(pre + "§7Kayit durdu. vurus: " + pd.recHits + ", kaydedilen ornek: " + pd.recSamples); }
            default -> s.sendMessage(pre + "§c/bloodac kayit <oyuncu> <legit|cheat|dur>");
        }
    }

    private void logs(CommandSender s, String[] a) {
        if (plugin.db() == null) { s.sendMessage(plugin.prefix() + "§cVeritabani kapali."); return; }
        if (a.length < 2) { s.sendMessage(plugin.prefix() + "§c/bloodac loglar <oyuncu>"); return; }
        String name = a[1].replaceAll("[^A-Za-z0-9_]", "");
        plugin.db().select("bloodac_violations",
                "select=check_name,vl,info,created_at&player_name=eq." + name + "&order=created_at.desc&limit=10")
                .whenComplete((rows, err) -> {
                    if (err != null) {
                        plugin.reply(s, "§cLoglar okunamadi. Loglari okumak icin config.yml'de supabase.secret-key gerekir (publishable key okuyamaz).");
                        plugin.getLogger().warning("loglar: " + err.getMessage());
                        return;
                    }
                    if (rows.size() == 0) { plugin.reply(s, "§7Kayit yok."); return; }
                    for (var e : rows) {
                        JsonObject o = e.getAsJsonObject();
                        String info = o.get("info").isJsonNull() ? "" : o.get("info").getAsString();
                        plugin.reply(s, "§f" + name + " §8- §c" + o.get("check_name").getAsString()
                                + " §8(vl: " + String.format("%.1f", o.get("vl").getAsDouble()) + ") §7" + info
                                + " §8" + o.get("created_at").getAsString().replace('T', ' ').substring(0, 19));
                    }
                });
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) SUB.stream().filter(x -> x.startsWith(a[0].toLowerCase(java.util.Locale.ROOT))).forEach(out::add);
        else if (a.length == 2 && (a[0].equalsIgnoreCase("animasyon") || a[0].equalsIgnoreCase("kayit") || a[0].equalsIgnoreCase("loglar") || a[0].equalsIgnoreCase("bilgi") || a[0].equalsIgnoreCase("sifirla")))
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        else if (a.length == 3 && a[0].equalsIgnoreCase("kayit")) out.addAll(List.of("legit", "cheat", "dur"));
        return out;
    }
}
