package net.bloodac;

import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

/**
 * AuraFix: KillAura rotasyon modlarinin (Smooth, Assist, Polar, Sloth, ReallyWorld/Snaps, ...) bakis izlerini arar.
 * Her alt kontrol tamponludur (tek seferlik tesaduf flag atmaz) ve yalnizca dovus sirasinda calisir.
 *
 *  - Pitch  : hedefin yukseklik acisindan cok farkli bakarken vurma (Sloth'un yukari bakisi)
 *  - Sabit  : ayni buyuk bakis hizinin tam tekrari (Assist'in hiz sinirlamasi)
 *  - Titresim: iki yone buyuk, duzenli salinim (Polar)
 *  - Kilit  : hedefin gozune surekli tam kilitli bakis (Smooth, ElytraTarget benzeri)
 *  - Snap   : vurustan hemen once buyuk ani donus ve tam isabet (Snaps/ReallyWorld)
 */
public final class AuraFix {
    private final BloodAC plugin;

    public AuraFix(BloodAC plugin) { this.plugin = plugin; }

    private long swapWindow() { return (long) c("swap.window-ms", 120); }

    private double c(String path, double def) { return plugin.getConfig().getDouble("checks.aurafix." + path, def); }

    /** Gecerli yakin dovus vurusunda (kayit modu disinda, 'safe' ise) cagrilir. */
    public void onHit(Player p, PlayerData pd, LivingEntity t, long now) {
        if (!plugin.getConfig().getBoolean("checks.aurafix.enabled", true) || p.isGliding()) return;
        Location eye = p.getEyeLocation();
        BoundingBox box = t.getBoundingBox();

        // ---- Reach spoof adayi: vurustan hemen once hedefe dogru buyuk bir ileri atilis ----
        boolean jump = false;
        if (pd.lastMoveVecMs != 0 && now - pd.lastMoveVecMs <= 120) {
            double[] mv = pd.lastMoveVec;
            double m = Math.sqrt(mv[0] * mv[0] + mv[1] * mv[1] + mv[2] * mv[2]);
            if (m >= c("spoof.min-jump", 1.0)) {
                Location tl = t.getLocation();
                double tx = tl.getX() - pd.lastMoveFrom[0], ty = tl.getY() - pd.lastMoveFrom[1], tz = tl.getZ() - pd.lastMoveFrom[2];
                double tm = Math.sqrt(tx * tx + ty * ty + tz * tz);
                if (tm > 0.1 && (mv[0] * tx + mv[1] * ty + mv[2] * tz) / (m * tm) >= 0.7) {
                    jump = true;
                    pd.spoofVec = mv.clone();
                    pd.spoofMs = now;
                }
            }
        }
        if (!jump) pd.buffer("af_spoof", false, c("spoof.buffer", 2));

        // ---- Takas sandvici: vurustan once esya degisimi, vurustan hemen sonra tekrar (Maximum damage / Auto mace) ----
        if (pd.pendingHitMs != 0 && now - pd.pendingHitMs > swapWindow()) {
            pd.pendingHitMs = 0;
            pd.buffer("af_swap", false, 2); // onceki vurusta sandvic tamamlanmadi: tamponu dusur
        }
        pd.pendingHitMs = (pd.lastSwapMs != 0 && now - pd.lastSwapMs <= swapWindow()) ? now : 0;

        // ---- Blok patlamasi: ayni anda (60 ms) 3+ FARKLI blokta kirma baslatip hemen vurma (Hit through blocks: Shard) ----
        synchronized (pd.blockDmg) {
            pd.blockDmg.removeIf(b -> now - b[0] > c("blocks.window-ms", 100));
            long distinct = pd.blockDmg.stream().mapToLong(b -> b[1]).distinct().count();
            boolean burst = distinct >= (int) c("blocks.min-blocks", 3);
            if (burst) pd.blockDmg.clear();
            if (pd.buffer("af_blocks", burst, c("blocks.buffer", 2))) {
                hit(p, pd, now, "AuraFix (Blok)", "vurustan once cok blokta kirma baslatildi");
            }
        }

        // ---- Pitch: bakis acisi hedef kutusunun (ust/alt) goruntu aralaginin cok disinda ----
        double hx = Math.max(box.getMinX() - eye.getX(), Math.max(0, eye.getX() - box.getMaxX()));
        double hz = Math.max(box.getMinZ() - eye.getZ(), Math.max(0, eye.getZ() - box.getMaxZ()));
        double horiz = Math.hypot(hx, hz);
        if (horiz > 1.5 && !t.isInWater()) {
            double up = -Math.toDegrees(Math.atan2(box.getMaxY() - eye.getY(), horiz));   // kutunun ustune bakis (daha negatif)
            double down = -Math.toDegrees(Math.atan2(box.getMinY() - eye.getY(), horiz)); // kutunun altina bakis
            double lo = Math.min(up, down), hi = Math.max(up, down);
            double pitch = eye.getPitch();
            double err = pitch < lo ? lo - pitch : (pitch > hi ? pitch - hi : 0);
            boolean bad = err > c("pitch.max-error", 40);
            if (pd.buffer("af_pitch", bad, c("pitch.buffer", 3))) {
                hit(p, pd, now, "AuraFix (Pitch)", String.format("pitch=%.0f aralik=%.0f..%.0f", pitch, lo, hi));
            }
        }

        double[][] d = pd.snapshot();

        // ---- Snap: vurustan once buyuk donus + isabet, 8 vurusun en az N'inde ----
        if (d.length >= 3) {
            double flick = 0;
            for (int k = d.length - 3; k < d.length; k++) flick = Math.max(flick, Math.abs(d[k][0]));
            boolean onBox = box.clone().expand(0.1).rayTrace(eye.toVector(), eye.getDirection(), 8) != null;
            boolean far = t.getLocation().distance(p.getLocation()) >= c("snap.min-distance", 2.2);
            pd.snapHits.addLast(far && onBox && flick >= c("snap.min-flick", 35));
            while (pd.snapHits.size() > 8) pd.snapHits.removeFirst();
            long n = pd.snapHits.stream().filter(b -> b).count();
            if (pd.snapHits.size() >= 8 && n >= (long) c("snap.min-hits", 5)) {
                pd.snapHits.clear();
                hit(p, pd, now, "AuraFix (Snap)", "vurustan once ani donus x" + n);
            }
        }

        // ---- pencere kontrolleri (en fazla 500 ms'de bir) ----
        if (d.length >= PlayerData.WINDOW && now - pd.afLastEvalMs >= 500) {
            pd.afLastEvalMs = now;
            windowChecks(p, pd, d, now);
        }
    }

    /** Ard arda ayni buyuk yaw degerinin en uzun tekrari (fare GCD'sinin >=2.5 kati). */
    static int constantRun(double[][] d, double minAbs) {
        double g = Double.MAX_VALUE;
        for (double[] r : d) {
            if (Math.abs(r[0]) > 1e-4) g = Math.min(g, Math.abs(r[0]));
            if (Math.abs(r[1]) > 1e-4) g = Math.min(g, Math.abs(r[1]));
        }
        int run = 1, best = 0;
        for (int k = 1; k < d.length; k++) {
            boolean same = Math.abs(d[k][0]) >= minAbs && Math.abs(d[k][0] - d[k - 1][0]) < 0.001
                    && Math.abs(d[k][0]) / g >= 2.5;
            run = same ? run + 1 : 1;
            best = Math.max(best, run);
        }
        return best;
    }

    /** {buyuk (>=3 derece) hareketler arasinda yon degistirme sayisi, ortalama |yaw delta|}. */
    static double[] oscillation(double[][] d) {
        int alt = 0, last = 0;
        double sum = 0;
        for (double[] r : d) {
            sum += Math.abs(r[0]);
            if (Math.abs(r[0]) >= 3) {
                int sign = r[0] > 0 ? 1 : -1;
                if (last != 0 && sign != last) alt++;
                last = sign;
            }
        }
        return new double[]{alt, sum / d.length};
    }

    /** {hedefli adim sayisi, ortalama goze hata, ortalama bakis aktivitesi}. */
    static double[] eyeLock(double[][] d) {
        int cnt = 0;
        double errSum = 0, act = 0;
        for (double[] r : d) {
            if (r.length > 3 && r[3] >= 0) { cnt++; errSum += r[3]; act += Math.abs(r[0]); }
        }
        return cnt == 0 ? new double[]{0, 0, 0} : new double[]{cnt, errSum / cnt, act / cnt};
    }

    /**
     * Aktif (|delta| >= minSpeed) ardisik adim ciftlerinin cogunda hiz degisimi (|ikinci fark|) <= maxJerk ve
     * hicbir adimda |delta| > maxSpeed olmamasi: insan farei bu kadar puruzsuz ve sinirli hizlanmaz.
     */
    static boolean accelLimited(double[][] d, int axis, double minSpeed, double maxSpeed, double maxJerk, int minPairs, double minFraction) {
        int pairs = 0, smooth = 0;
        for (int k = 0; k < d.length; k++) {
            if (Math.abs(d[k][axis]) > maxSpeed) return false;
            if (k > 0 && Math.abs(d[k][axis]) >= minSpeed && Math.abs(d[k - 1][axis]) >= minSpeed) {
                pairs++;
                if (Math.abs(d[k][axis] - d[k - 1][axis]) <= maxJerk) smooth++;
            }
        }
        return pairs >= minPairs && smooth >= minFraction * pairs;
    }

    /**
     * Her hareket olayinda cagrilir (kayit modu disinda). Reach spoof: hile, hedefe dogru tek pakette >=0.9 blok "atlayip"
     * vurur, hemen ardindan eski konuma geri doner. Atilis + vurus + ayni buyuklukte zit yonlu donus aranir.
     */
    public void onMove(Player p, PlayerData pd, org.bukkit.Location from, org.bukkit.Location to, long now) {
        double dx = to.getX() - from.getX(), dy = to.getY() - from.getY(), dz = to.getZ() - from.getZ();
        boolean skip = !plugin.getConfig().getBoolean("checks.aurafix.enabled", true)
                || p.isGliding() || p.isInsideVehicle() || now < pd.ignoreUntilMs;
        if (!skip && pd.spoofMs != 0) {
            if (now - pd.spoofMs <= c("spoof.return-ms", 250)) {
                double[] s = pd.spoofVec;
                double m2 = s[0] * s[0] + s[1] * s[1] + s[2] * s[2];
                double dot = dx * s[0] + dy * s[1] + dz * s[2];
                if (m2 > 0 && dot <= -c("spoof.return-ratio", 0.7) * m2) {
                    pd.spoofMs = 0;
                    if (pd.buffer("af_spoof", true, c("spoof.buffer", 2))) {
                        hit(p, pd, now, "AuraFix (Reach)", String.format("hedefe %.1f blok atilip geri donuldu", Math.sqrt(m2)));
                    }
                }
            } else {
                pd.spoofMs = 0;
            }
        }
        if (skip) pd.spoofMs = 0;
        pd.lastMoveVec[0] = dx; pd.lastMoveVec[1] = dy; pd.lastMoveVec[2] = dz;
        pd.lastMoveFrom[0] = from.getX(); pd.lastMoveFrom[1] = from.getY(); pd.lastMoveFrom[2] = from.getZ();
        pd.lastMoveVecMs = now;
    }

    /** Esya/el degisimi olayi (swap, kisayol tusu, slot degisimi, envanter tiklamasi). */
    public void onSwap(Player p, PlayerData pd, long now) {
        if (!plugin.getConfig().getBoolean("checks.aurafix.enabled", true)) return;
        if (pd.pendingHitMs != 0 && now >= pd.pendingHitMs && now - pd.pendingHitMs <= swapWindow()) {
            pd.pendingHitMs = 0;
            if (pd.buffer("af_swap", true, c("swap.buffer", 3))) {
                hit(p, pd, now, "AuraFix (Takas)", "vurusun onunde ve arkasinda esya degisimi");
            }
        }
        pd.lastSwapMs = now;
    }

    /** Blok kirma baslangici (BlockDamageEvent). */
    public void onBlockDamage(PlayerData pd, long now, long packedPos) {
        synchronized (pd.blockDmg) {
            pd.blockDmg.addLast(new long[]{now, packedPos});
            while (pd.blockDmg.size() > 12) pd.blockDmg.removeFirst();
        }
    }

    private void windowChecks(Player p, PlayerData pd, double[][] d, long now) {
        int best = constantRun(d, c("constant.min-speed", 1.5));
        if (pd.buffer("af_const", best >= (int) c("constant.min-run", 8), c("constant.buffer", 2))) {
            hit(p, pd, now, "AuraFix (Sabit)", "ayni bakis hizi x" + best);
        }

        double[] o = oscillation(d);
        boolean osc = o[0] >= c("oscillation.min-alt", 10) && o[1] >= c("oscillation.min-mean", 6);
        if (pd.buffer("af_osc", osc, c("oscillation.buffer", 3))) {
            hit(p, pd, now, "AuraFix (Titresim)", String.format("salinim=%d ort=%.1f", (int) o[0], o[1]));
        }

        // Ivme sinirli rotasyon (AuraYawTracker / AuraPitchTracker). Tek basina ayirt edici degil (puruzsuz insan hareketine
        // benzer), bu yuzden yalnizca AI kaniti da yukselmisse sayilir (accel.require-ai).
        boolean aiOk = true;
        if (plugin.getConfig().getBoolean("checks.aurafix.accel.require-ai", true)) {
            Model m = plugin.model();
            aiOk = m != null && pd.cusum >= m.cusumH * c("accel.ai-fraction", 0.4);
        }
        boolean yawLim = aiOk && accelLimited(d, 0, c("accel.yaw-min-speed", 1.0), c("accel.yaw-max-speed", 4.6),
                c("accel.yaw-max-jerk", 0.25), (int) c("accel.yaw-min-pairs", 25), c("accel.min-fraction", 0.98));
        if (pd.buffer("af_accel_y", yawLim, c("accel.buffer", 2))) {
            hit(p, pd, now, "AuraFix (Ivme)", "yaw hizi ivme sinirli");
        }
        boolean pitLim = aiOk && accelLimited(d, 1, c("accel.pitch-min-speed", 0.4), c("accel.pitch-max-speed", 1.9),
                c("accel.pitch-max-jerk", 0.2), (int) c("accel.pitch-min-pairs", 22), c("accel.min-fraction", 0.98));
        if (pd.buffer("af_accel_p", pitLim, c("accel.buffer", 2))) {
            hit(p, pd, now, "AuraFix (Ivme-Pitch)", "pitch hizi ivme sinirli");
        }

        double[] l = eyeLock(d);
        boolean lock = l[0] >= 30 && l[1] < c("lock.max-error", 0.4) && l[2] >= c("lock.min-activity", 1.0);
        if (pd.buffer("af_lock", lock, c("lock.buffer", 3))) {
            hit(p, pd, now, "AuraFix (Kilit)", String.format("ort.hata=%.2f", l[1]));
        }
    }

    private void hit(Player p, PlayerData pd, long now, String check, String info) {
        plugin.flag(p, check, c("vl", 2.0), info);
        // flag'li oyuncunun vuruslari kisa sure engellenir (aura hasari verilmez)
        if (plugin.getConfig().getBoolean("checks.aurafix.cancel-hits", true)) {
            pd.cancelUntilMs = now + (long) c("cancel-ms", 3000);
        }
    }
}
