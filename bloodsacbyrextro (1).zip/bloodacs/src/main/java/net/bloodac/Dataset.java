package net.bloodac;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * veri.dat formati (v2): "BAC2" + kayitlar. Kayit = 1 bayt etiket (1=cheat), 1 bayt n, n adet double.
 * Eski format (basliksiz, 9 ozellik) ilk acilista otomatik donusturulur; eskisi veri.dat.bak olarak saklanir.
 */
public final class Dataset {
    private static final int MAGIC = 0x42414332;

    public record Rec(int label, double[] x) {}

    private final File file;

    public Dataset(File file) { this.file = file; }

    public synchronized void migrate() throws IOException {
        if (!file.exists() || file.length() == 0) return;
        try (var in = new DataInputStream(new FileInputStream(file))) {
            if (file.length() >= 4 && in.readInt() == MAGIC) return;
        }
        List<Rec> old = new ArrayList<>();
        try (var in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            while (true) {
                int lab = in.read();
                if (lab < 0) break;
                double[] x = new double[PlayerData.LEGACY_FEATURES];
                for (int i = 0; i < x.length; i++) x[i] = in.readDouble();
                old.add(new Rec(lab, x));
            }
        } catch (EOFException ignored) { /* yarim kayit */ }
        File bak = new File(file.getParentFile(), file.getName() + ".bak");
        if (!bak.exists()) Files.copy(file.toPath(), bak.toPath(), StandardCopyOption.REPLACE_EXISTING);
        file.delete();
        for (Rec r : old) append(r.label, r.x);
    }

    public synchronized void append(int label, double[] x) throws IOException {
        file.getParentFile().mkdirs();
        boolean fresh = !file.exists() || file.length() == 0;
        try (var out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file, true)))) {
            if (fresh) out.writeInt(MAGIC);
            out.writeByte(label);
            out.writeByte(x.length);
            for (double d : x) out.writeDouble(d);
        }
    }

    public synchronized List<Rec> readAll() {
        List<Rec> list = new ArrayList<>();
        if (!file.exists() || file.length() < 4) return list;
        try (var in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            if (in.readInt() != MAGIC) return list;
            while (true) {
                int lab = in.read();
                if (lab < 0) break;
                int n = in.readUnsignedByte();
                double[] x = new double[n];
                for (int i = 0; i < n; i++) x[i] = in.readDouble();
                list.add(new Rec(lab, x));
            }
        } catch (IOException ignored) { /* yarim kalan son kayit atlanir */ }
        return list;
    }
}
