package net.bloodac;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.Random;

/** Kucuk gradyan artirmali karar agaclari (lojistik kayip, Newton adimi). Tablo verisinde sinir agindan genelde saglamdir. */
public final class Gbdt {
    private static final class Tree {
        int[] feat, left, right;
        double[] thr, val;
        int size;

        Tree(int cap) {
            feat = new int[cap]; left = new int[cap]; right = new int[cap];
            thr = new double[cap]; val = new double[cap];
        }

        int add() { return size++; }

        double predict(double[] x) {
            int n = 0;
            while (feat[n] >= 0) n = x[feat[n]] <= thr[n] ? left[n] : right[n];
            return val[n];
        }
    }

    public static final class Params {
        public int rounds = 120, depth = 3, minLeaf = 6, bins = 16;
        public double lr = 0.08, lambda = 2.0, subsample = 0.8, colsample = 0.8;
    }

    private final int n;
    private final double base;
    private final Tree[] trees;
    private final double lr;

    private Gbdt(int n, double base, Tree[] trees, double lr) {
        this.n = n; this.base = base; this.trees = trees; this.lr = lr;
    }

    public double predictRaw(double[] x) {
        double s = base;
        for (Tree t : trees) s += lr * t.predict(x);
        return s;
    }

    public double predict(double[] x) { return 1.0 / (1.0 + Math.exp(-predictRaw(x))); }

    /** x: n ozellikli satirlar, y: 0/1, w: ornek agirligi. */
    public static Gbdt train(double[][] x, double[] y, double[] w, int n, Params p, Random rnd) {
        int m = x.length;
        double sw = 0, sp = 0;
        for (int i = 0; i < m; i++) { sw += w[i]; sp += w[i] * y[i]; }
        double pr = Math.min(0.99, Math.max(0.01, sp / sw));
        double base = Math.log(pr / (1 - pr));

        double[][] cuts = new double[n][];
        for (int f = 0; f < n; f++) {
            double[] col = new double[m];
            for (int i = 0; i < m; i++) col[i] = x[i][f];
            java.util.Arrays.sort(col);
            java.util.List<Double> c = new java.util.ArrayList<>();
            for (int b = 1; b < p.bins; b++) {
                double v = col[Math.min(m - 1, b * m / p.bins)];
                if (c.isEmpty() || v > c.get(c.size() - 1)) c.add(v);
            }
            cuts[f] = c.stream().mapToDouble(Double::doubleValue).toArray();
        }

        double[] F = new double[m];
        java.util.Arrays.fill(F, base);
        Tree[] trees = new Tree[p.rounds];
        double[] g = new double[m], h = new double[m];
        for (int r = 0; r < p.rounds; r++) {
            for (int i = 0; i < m; i++) {
                double pi = 1.0 / (1.0 + Math.exp(-F[i]));
                g[i] = w[i] * (y[i] - pi);
                h[i] = w[i] * Math.max(pi * (1 - pi), 1e-6);
            }
            int[] rows = sample(m, p.subsample, rnd);
            boolean[] cols = new boolean[n];
            int any = 0;
            for (int f = 0; f < n; f++) { cols[f] = rnd.nextDouble() < p.colsample; if (cols[f]) any++; }
            if (any == 0) cols[rnd.nextInt(n)] = true;

            Tree t = new Tree((1 << (p.depth + 1)) + 1);
            grow(t, t.add(), rows, rows.length, x, g, h, cuts, cols, p, 0);
            trees[r] = t;
            for (int i = 0; i < m; i++) F[i] += p.lr * t.predict(x[i]);
        }
        return new Gbdt(n, base, trees, p.lr);
    }

    private static int[] sample(int m, double frac, Random rnd) {
        int[] tmp = new int[m];
        int c = 0;
        for (int i = 0; i < m; i++) if (rnd.nextDouble() < frac) tmp[c++] = i;
        return java.util.Arrays.copyOf(tmp, c);
    }

    private static void grow(Tree t, int node, int[] rows, int cnt, double[][] x, double[] g, double[] h,
                             double[][] cuts, boolean[] cols, Params p, int depth) {
        double G = 0, H = 0;
        for (int i = 0; i < cnt; i++) { G += g[rows[i]]; H += h[rows[i]]; }
        t.val[node] = G / (H + p.lambda);
        t.feat[node] = -1;
        if (depth >= p.depth || cnt < 2 * p.minLeaf) return;

        double bestGain = 1e-9, bestThr = 0;
        int bestF = -1;
        double parent = G * G / (H + p.lambda);
        for (int f = 0; f < cuts.length; f++) {
            if (!cols[f]) continue;
            for (double c : cuts[f]) {
                double gl = 0, hl = 0;
                int nl = 0;
                for (int i = 0; i < cnt; i++) {
                    int r = rows[i];
                    if (x[r][f] <= c) { gl += g[r]; hl += h[r]; nl++; }
                }
                int nr = cnt - nl;
                if (nl < p.minLeaf || nr < p.minLeaf) continue;
                double gr = G - gl, hr = H - hl;
                double gain = gl * gl / (hl + p.lambda) + gr * gr / (hr + p.lambda) - parent;
                if (gain > bestGain) { bestGain = gain; bestF = f; bestThr = c; }
            }
        }
        if (bestF < 0) return;
        int[] l = new int[cnt], rr = new int[cnt];
        int nl = 0, nr = 0;
        for (int i = 0; i < cnt; i++) {
            if (x[rows[i]][bestF] <= bestThr) l[nl++] = rows[i]; else rr[nr++] = rows[i];
        }
        t.feat[node] = bestF;
        t.thr[node] = bestThr;
        t.left[node] = t.add();
        t.right[node] = t.add();
        grow(t, t.left[node], l, nl, x, g, h, cuts, cols, p, depth + 1);
        grow(t, t.right[node], rr, nr, x, g, h, cuts, cols, p, depth + 1);
    }

    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        o.addProperty("n", n);
        o.addProperty("base", base);
        o.addProperty("lr", lr);
        JsonArray ts = new JsonArray();
        for (Tree t : trees) {
            JsonObject j = new JsonObject();
            JsonArray f = new JsonArray(), th = new JsonArray(), l = new JsonArray(), r = new JsonArray(), v = new JsonArray();
            for (int i = 0; i < t.size; i++) { f.add(t.feat[i]); th.add(t.thr[i]); l.add(t.left[i]); r.add(t.right[i]); v.add(t.val[i]); }
            j.add("f", f); j.add("t", th); j.add("l", l); j.add("r", r); j.add("v", v);
            ts.add(j);
        }
        o.add("trees", ts);
        return o;
    }

    public static Gbdt fromJson(JsonObject o) {
        JsonArray ts = o.getAsJsonArray("trees");
        Tree[] trees = new Tree[ts.size()];
        for (int k = 0; k < trees.length; k++) {
            JsonObject j = ts.get(k).getAsJsonObject();
            int sz = j.getAsJsonArray("f").size();
            Tree t = new Tree(sz);
            t.size = sz;
            for (int i = 0; i < sz; i++) {
                t.feat[i] = j.getAsJsonArray("f").get(i).getAsInt();
                t.thr[i] = j.getAsJsonArray("t").get(i).getAsDouble();
                t.left[i] = j.getAsJsonArray("l").get(i).getAsInt();
                t.right[i] = j.getAsJsonArray("r").get(i).getAsInt();
                t.val[i] = j.getAsJsonArray("v").get(i).getAsDouble();
            }
            trees[k] = t;
        }
        return new Gbdt(o.get("n").getAsInt(), o.get("base").getAsDouble(), trees, o.get("lr").getAsDouble());
    }
}
