package net.bloodac;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

/** Minimal Supabase PostgREST istemcisi (secret key ile, sunucu tarafi). */
public final class Supabase {
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final String base;
    private final String key;

    public Supabase(String url, String secretKey) {
        this.base = url.replaceAll("/+$", "") + "/rest/v1/";
        this.key = secretKey;
    }

    private HttpRequest.Builder req(String path) {
        // Yeni sb_secret_ anahtarlari JWT degildir: yalnizca apikey basligi kullanilir.
        return HttpRequest.newBuilder(URI.create(base + path))
                .timeout(Duration.ofSeconds(20))
                .header("apikey", key)
                .header("Content-Type", "application/json");
    }

    private CompletableFuture<String> run(HttpRequest r) {
        return http.sendAsync(r, HttpResponse.BodyHandlers.ofString()).thenApply(res -> {
            if (res.statusCode() >= 300) {
                throw new IllegalStateException("Supabase " + res.statusCode() + ": " + res.body());
            }
            return res.body();
        });
    }

    public CompletableFuture<String> insert(String table, JsonElement rows) {
        return run(req(table).header("Prefer", "return=minimal")
                .POST(HttpRequest.BodyPublishers.ofString(rows.toString())).build());
    }

    public CompletableFuture<String> upsert(String table, JsonElement row) {
        return run(req(table).header("Prefer", "resolution=merge-duplicates,return=minimal")
                .POST(HttpRequest.BodyPublishers.ofString(row.toString())).build());
    }

    /** query ornek: "select=*&label=eq.legit&limit=5000" */
    public CompletableFuture<JsonArray> select(String table, String query) {
        return run(req(table + "?" + query).GET().build())
                .thenApply(body -> JsonParser.parseString(body).getAsJsonArray());
    }
}
