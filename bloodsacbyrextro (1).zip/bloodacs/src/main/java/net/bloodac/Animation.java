package net.bloodac;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Yaml tanimli ceza animasyonu (MLSAC animasyon formati ile uyumlu). */
public final class Animation {
    private static final Map<String, String> ALIAS = Map.of(
            "DUST", "REDSTONE", "SMOKE", "SMOKE_NORMAL", "LARGE_SMOKE", "SMOKE_LARGE",
            "FIREWORK", "FIREWORKS_SPARK", "EXPLOSION", "EXPLOSION_NORMAL");
    private static final Random RND = new Random();

    private Animation() {}

    /**
     * @param test true ise esyalari birakmaz ve atmaz (ayar denemek icin)
     * @param onEnd animasyon bitince (oyuncu hala cevrimiciyse) calisir; null olabilir
     */
    public static void play(BloodAC plugin, Player p, YamlConfiguration cfg, boolean test, Runnable onEnd) {
        PlayerData pd = plugin.data(p);
        final int total = cfg.getInt("totalTicks", 90);
        final boolean freeze = cfg.getBoolean("freezePlayer", true);
        final boolean strip = cfg.getBoolean("stripPlayer", false) && !test;
        final int dropEvery = Math.max(1, cfg.getInt("itemDropIntervalTicks", 5));
        final int lev = cfg.getInt("customLevitationAmplifier", 0);
        final boolean lightning = cfg.getBoolean("strikeLightningAtEnd", false);
        final var mv = cfg.getConfigurationSection("movement");
        final List<Map<?, ?>> stages = cfg.getMapList("stages");

        final Location origin = p.getLocation().clone();
        final boolean oldGravity = p.hasGravity();
        final boolean oldInv = p.isInvulnerable();
        p.leaveVehicle();
        p.setGliding(false); // elytra ile suzulen oyuncu animasyonda havada kalmasin
        pd.frozen = freeze;
        p.setInvulnerable(true);
        if (mv != null) p.setGravity(false);
        else if (lev > 0) p.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, total + 5, lev - 1, false, false, false));

        new BukkitRunnable() {
            int tick = 0;

            void cleanup() {
                pd.frozen = false;
                if (p.isOnline()) {
                    p.setGravity(oldGravity);
                    p.setInvulnerable(oldInv);
                    p.removePotionEffect(PotionEffectType.LEVITATION);
                }
            }

            @Override
            public void run() {
                if (!p.isOnline()) { cleanup(); cancel(); return; }
                tick++;
                if (p.isGliding()) p.setGliding(false);

                if (mv != null) {
                    int s = mv.getInt("startTick", 1), e = Math.max(s + 1, mv.getInt("endTick", total));
                    double t = Math.max(0, Math.min(1, (tick - s) / (double) (e - s)));
                    if (mv.getBoolean("smooth", true)) t = t * t * (3 - 2 * t);
                    Location to = origin.clone().add(mv.getDouble("offsetX", 0) * t, mv.getDouble("offsetY", 0) * t, mv.getDouble("offsetZ", 0) * t);
                    to.setYaw(p.getLocation().getYaw());
                    to.setPitch(p.getLocation().getPitch());
                    p.teleport(to);
                }

                if (strip && tick % dropEvery == 0) dropOne(p);

                for (Map<?, ?> st : stages) {
                    int s = i(st, "startTick", 1), e = i(st, "endTick", total);
                    if (tick < s || tick > e) continue;
                    double t = e == s ? 1 : (tick - s) / (double) (e - s);
                    for (Object o : list(st.get("particles"))) if (o instanceof Map<?, ?> pm) emit(p, pm, tick, s, t);
                    if (st.get("particleTrail") instanceof Map<?, ?> tr) emit(p, tr, tick, s, t);
                    for (Object o : list(st.get("sounds"))) if (o instanceof Map<?, ?> sm) sound(p, sm, tick - s);
                }

                if (tick >= total) {
                    cancel();
                    if (strip) dropAll(p);
                    if (lightning) p.getWorld().strikeLightningEffect(p.getLocation());
                    cleanup();
                    if (onEnd != null) onEnd.run();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ---------------- parcaciklar ----------------

    private static void emit(Player p, Map<?, ?> m, int tick, int stageStart, double t) {
        int every = Math.max(1, i(m, "intervalTicks", 1));
        if ((tick - stageStart) % every != 0) return;
        Particle part = particle(s(m, "particleType", "SMOKE"));
        // ozel veri isteyen (item/blok/gecis rengi) parcaciklar desteklenmez; dust disinda veri gerektirenleri atla
        if (part == null || (part.getDataType() != Void.class && part.getDataType() != Particle.DustOptions.class)) return;
        int count = Math.max(1, i(m, "count", 1));
        String shape = s(m, "shape", "").toUpperCase(java.util.Locale.ROOT);
        double rad = lerp(d(m, "radiusStart", 0), d(m, "radiusEnd", 0), t);
        double hs = d(m, "heightOffsetStart", 0), he = d(m, "heightOffsetEnd", hs);
        double speed = d(m, "speed", 0);
        World w = p.getWorld();
        Location c = p.getLocation();
        Object data = data(part, m);

        switch (shape) {
            case "HELIX", "RISING_SPIRAL" -> {
                boolean twin = shape.equals("HELIX");
                for (int k = 0; k < count; k++) {
                    double f = k / (double) count;
                    double ang = tick * 0.35 + f * Math.PI * 4;
                    double y = lerp(hs, he, f);
                    put(w, part, c.clone().add(Math.cos(ang) * rad, y, Math.sin(ang) * rad), speed, data);
                    if (twin) put(w, part, c.clone().add(Math.cos(ang + Math.PI) * rad, y, Math.sin(ang + Math.PI) * rad), speed, data);
                }
            }
            case "CIRCLE" -> {
                double y = lerp(hs, he, t);
                for (int k = 0; k < count; k++) {
                    double ang = k / (double) count * Math.PI * 2 + tick * 0.2;
                    put(w, part, c.clone().add(Math.cos(ang) * rad, y, Math.sin(ang) * rad), speed, data);
                }
            }
            case "SPHERE", "EXPLOSION" -> {
                double y = lerp(hs, he, t);
                for (int k = 0; k < count; k++) {
                    Vector v = new Vector(RND.nextGaussian(), RND.nextGaussian(), RND.nextGaussian());
                    if (v.lengthSquared() < 1e-6) continue;
                    v.normalize().multiply(rad);
                    put(w, part, c.clone().add(v.getX(), y + v.getY(), v.getZ()), speed, data);
                }
            }
            default -> {
                // iz (trail) veya sekilsiz: ayak civarinda rastgele yayilim
                double ox = d(m, "offsetX", Math.max(rad, 0.3)), oy = d(m, "offsetY", 0.3), oz = d(m, "offsetZ", Math.max(rad, 0.3));
                double y = lerp(hs, he, t);
                for (int k = 0; k < count; k++) {
                    put(w, part, c.clone().add((RND.nextDouble() * 2 - 1) * ox, y + RND.nextDouble() * oy, (RND.nextDouble() * 2 - 1) * oz), speed, data);
                }
            }
        }
    }

    private static void put(World w, Particle part, Location l, double speed, Object data) {
        w.spawnParticle(part, l, 1, 0, 0, 0, speed, data);
    }

    private static Object data(Particle part, Map<?, ?> m) {
        if (part.getDataType() == Particle.DustOptions.class) {
            boolean col = b(m, "isColored", false);
            Color c = col ? Color.fromRGB(clamp(i(m, "red", 255)), clamp(i(m, "green", 255)), clamp(i(m, "blue", 255))) : Color.WHITE;
            return new Particle.DustOptions(c, (float) d(m, "particleSize", 1.0));
        }
        return null;
    }

    private static Particle particle(String name) {
        String n = name.toUpperCase(java.util.Locale.ROOT);
        try { return Particle.valueOf(n); } catch (IllegalArgumentException ignored) { }
        String a = ALIAS.get(n);
        if (a != null) try { return Particle.valueOf(a); } catch (IllegalArgumentException ignored) { }
        return null;
    }

    // ---------------- sesler ----------------

    private static void sound(Player p, Map<?, ?> m, int rel) {
        int at = i(m, "playAtTick", 0);
        boolean loop = b(m, "loop", false);
        int every = Math.max(1, i(m, "loopIntervalTicks", 20));
        if (!(rel == at || (loop && rel > at && (rel - at) % every == 0))) return;
        try {
            Sound snd = Sound.valueOf(s(m, "soundType", "").toUpperCase(java.util.Locale.ROOT));
            p.getWorld().playSound(p.getLocation(), snd, (float) d(m, "volume", 1), (float) d(m, "pitch", 1));
        } catch (IllegalArgumentException ignored) { /* bilinmeyen ses adi */ }
    }

    // ---------------- esya birakma ----------------

    private static void dropOne(Player p) {
        List<Integer> slots = new ArrayList<>();
        ItemStack[] inv = p.getInventory().getContents();
        for (int k = 0; k < inv.length; k++) if (inv[k] != null && !inv[k].getType().isAir()) slots.add(k);
        if (slots.isEmpty()) return;
        int slot = slots.get(RND.nextInt(slots.size()));
        ItemStack it = inv[slot];
        p.getInventory().setItem(slot, null);
        p.getWorld().dropItemNaturally(p.getLocation().add(0, 1, 0), it);
    }

    private static void dropAll(Player p) {
        for (ItemStack it : p.getInventory().getContents()) {
            if (it != null && !it.getType().isAir()) p.getWorld().dropItemNaturally(p.getLocation().add(0, 1, 0), it);
        }
        p.getInventory().clear();
    }

    // ---------------- yardimcilar ----------------

    private static List<?> list(Object o) { return o instanceof List<?> l ? l : List.of(); }
    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }
    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }
    private static int i(Map<?, ?> m, String k, int def) { return m.get(k) instanceof Number n ? n.intValue() : def; }
    private static double d(Map<?, ?> m, String k, double def) { return m.get(k) instanceof Number n ? n.doubleValue() : def; }
    private static boolean b(Map<?, ?> m, String k, boolean def) { return m.get(k) instanceof Boolean v ? v : def; }
    private static String s(Map<?, ?> m, String k, String def) { return m.get(k) != null ? String.valueOf(m.get(k)) : def; }
}
